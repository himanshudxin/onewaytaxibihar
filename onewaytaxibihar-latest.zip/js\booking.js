/**
 * OneWayTaxiBihar (onewaytaxibihar.com) - Booking Engine & Route Controller
 * Covers all 38 Districts of Bihar + Connecting Outstations, 4 Trip Types,
 * Dynamic All-Inclusive Fares, Passenger Checkout, and Ticket Confirmation.
 */

class BookingManager {
  constructor() {
    this.tripType = "oneway"; // "oneway" | "roundtrip" | "rental" | "airport"
    this.rentalMode = "without_driver"; // "without_driver" | "with_driver"
    this.withDriver = false;
    this.activeFleetRates = null;
    this.activeSegmentFares = null;
    this.originCity = null; // Blank initially - set by user
    this.destCity = null;   // Blank initially - set by user
    
    const today = new Date();
    const formatYMD = (d) => {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${y}-${m}-${day}`;
    };
    this.pickupDate = formatYMD(today); // Only current date is filled initially
    this.pickupTime = "10:00 AM";
    this.returnDate = "";
    this.localPackageId = "pkg_8hr_80km";
    this.flightNumber = "";

    this.selectedCabId = "sedan";
    this.calculatedDistanceKm = 104;
    this.calculatedDuration = "2h 15m";
    this.calculatedToll = 110;
    this.userPhone = "";
    this.currentWhatsAppLeadUrl = "";
    this.isFareUnlocked = false;

    this.passengerDetails = {
      name: "",
      phone: "",
      email: "",
      pickupAddress: "",
      dropAddress: "",
      luggageCount: "2-3 Large Bags",
      gstin: "",
      companyName: ""
    };

    this.activeBooking = null;
    this.paymentMethod = "Cash / UPI to Driver";
    this.appliedCouponCode = "";
    this.appliedCouponDiscount = 0;
  }

  init() {
    this.setDefaultDates();
    this.setupAutocomplete();
    this.setupEventListeners();
    this.fetchFareConfig();
    this.renderPopularRouteChips();
    this.renderFriendsHeroReviews();
    this.renderWhyChooseCards();
    this.renderTestimonials();
    this.renderMajorCities();
    this.renderFAQs();
    this.renderFooterRoutes();

    // Do not feed data at first - client enters location and receives smart time-saving suggestions
    this.originCity = null;
    this.destCity = null;
    const pickupInput = document.getElementById("input-pickup");
    const dropInput = document.getElementById("input-drop");
    if (pickupInput && !this.originCity) {
      pickupInput.value = "";
    }
    // Parse Deep-link URL parameters (?from=Patna&to=Gaya)
    if (typeof window !== "undefined" && window.location.search) {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const fromParam = (urlParams.get("from") || urlParams.get("pickup") || "").trim();
        const toParam = (urlParams.get("to") || urlParams.get("drop") || "").trim();
        if (fromParam) {
          const matchedFrom = OTB_CITIES.find(c => c.name.toLowerCase() === fromParam.toLowerCase() || c.id === fromParam.toLowerCase());
          if (matchedFrom) {
            this.originCity = matchedFrom;
            if (pickupInput) pickupInput.value = `${matchedFrom.name} (${matchedFrom.hindiName || ''}), ${matchedFrom.state}`;
          }
        }
        if (toParam) {
          const matchedTo = OTB_CITIES.find(c => c.name.toLowerCase() === toParam.toLowerCase() || c.id === toParam.toLowerCase());
          if (matchedTo) {
            this.destCity = matchedTo;
            if (dropInput) dropInput.value = `${matchedTo.name} (${matchedTo.hindiName || ''}), ${matchedTo.state}`;
          }
        }
        const cabParam = (urlParams.get("cab") || "").trim().toLowerCase();
        if (cabParam) {
          this.selectedCabId = cabParam;
        }
      } catch (err) {}
    }

    // Auto-fill logged in user phone if available
    if (window.currentUser && window.currentUser.phone) {
      const cleanPhone = window.currentUser.phone.replace(/\D/g, "").slice(-10);
      this.userPhone = cleanPhone;
      this.passengerDetails.phone = `+91 ${cleanPhone}`;
      if (window.currentUser.name) {
        this.passengerDetails.name = window.currentUser.name;
      }
      const phoneInput = document.getElementById("input-fare-phone");
      if (phoneInput && !phoneInput.value) {
        phoneInput.value = cleanPhone;
      }
    }

    // Transparent Fares: Automatically show fares when route is configured
    const section = document.getElementById("cab-selection-section");
    const mapSection = document.getElementById("route-map-section");

    if (this.originCity && this.destCity) {
      this.isFareUnlocked = true;
      if (section) {
        section.classList.remove("fare-section-closed");
        section.classList.add("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.remove("fare-section-closed");
        mapSection.classList.add("fare-section-open");
      }
      this.calculateAndRenderFares();
    } else {
      this.isFareUnlocked = true;
      if (section) {
        section.classList.remove("fare-section-closed");
        section.classList.add("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.remove("fare-section-closed");
        mapSection.classList.add("fare-section-open");
      }
      this.calculateAndRenderFares();
    }

    // If deep-link params were supplied, smooth-scroll to cab options
    if (typeof window !== "undefined" && window.location.search) {
      try {
        const checkParams = new URLSearchParams(window.location.search);
        if (checkParams.get("from") || checkParams.get("to") || checkParams.get("cab") || window.location.hash === "#booking-hero") {
          setTimeout(() => {
            const targetEl = document.getElementById("cab-selection-section") || document.getElementById("booking-hero");
            targetEl?.scrollIntoView({ behavior: "smooth", block: "start" });
          }, 350);
        }
      } catch (e) {}
    }

    this.restoreState();
    this.syncPaymentConfig();
  }

  saveState() {
    try {
      const nameVal = document.getElementById("chk-name")?.value;
      const phoneVal = document.getElementById("chk-phone")?.value;
      const emailVal = document.getElementById("chk-email")?.value;
      const pickupAddrVal = document.getElementById("chk-pickup-addr")?.value;
      const dropAddrVal = document.getElementById("chk-drop-addr")?.value;

      if (nameVal !== undefined) this.passengerDetails.name = nameVal.trim();
      if (phoneVal !== undefined) this.passengerDetails.phone = phoneVal.trim();
      if (emailVal !== undefined) this.passengerDetails.email = emailVal.trim();
      if (pickupAddrVal !== undefined) this.passengerDetails.pickupAddress = pickupAddrVal.trim();
      if (dropAddrVal !== undefined) this.passengerDetails.dropAddress = dropAddrVal.trim();

      const state = {
        tripType: this.tripType,
        originCity: this.originCity,
        destCity: this.destCity,
        pickupDate: this.pickupDate,
        pickupTime: this.pickupTime,
        returnDate: this.returnDate,
        localPackageId: this.localPackageId,
        selectedCabId: this.selectedCabId,
        calculatedDistanceKm: this.calculatedDistanceKm,
        calculatedDuration: this.calculatedDuration,
        calculatedToll: this.calculatedToll,
        passengerDetails: this.passengerDetails,
        paymentMethod: document.querySelector('input[name="pay-method"]:checked')?.value || this.paymentMethod,
        useWallet: document.getElementById("chk-use-wallet")?.checked ?? true
      };
      sessionStorage.setItem("otb_booking_state", JSON.stringify(state));
      if (this.passengerDetails.name || this.passengerDetails.phone) {
        localStorage.setItem("otb_passenger_cache", JSON.stringify(this.passengerDetails));
      }
    } catch (e) {
      console.warn("Could not save booking state:", e);
    }
  }

  restoreState() {
    try {
      const raw = sessionStorage.getItem("otb_booking_state");
      if (raw) {
        const s = JSON.parse(raw);
        if (s.tripType) this.tripType = s.tripType;
        if (s.originCity) this.originCity = s.originCity;
        if (s.destCity) this.destCity = s.destCity;
        if (s.pickupDate) this.pickupDate = s.pickupDate;
        if (s.pickupTime) this.pickupTime = s.pickupTime;
        if (s.returnDate) this.returnDate = s.returnDate;
        if (s.localPackageId) this.localPackageId = s.localPackageId;
        if (s.selectedCabId) this.selectedCabId = s.selectedCabId;
        if (s.calculatedDistanceKm) this.calculatedDistanceKm = s.calculatedDistanceKm;
        if (s.calculatedDuration) this.calculatedDuration = s.calculatedDuration;
        if (s.calculatedToll) this.calculatedToll = s.calculatedToll;
        if (s.passengerDetails) Object.assign(this.passengerDetails, s.passengerDetails);
        if (s.paymentMethod) this.paymentMethod = s.paymentMethod;

        // Restore DOM inputs
        const formatCityLabel = (c) => c ? `${c.name}${c.district && c.district !== c.name && c.type !== 'airport' ? ', ' + c.district : ''} (${c.hindiName || ''}), ${c.state}` : "";
        const pInput = document.getElementById("input-pickup");
        const dInput = document.getElementById("input-drop");
        const dateInput = document.getElementById("pickup-date-input");
        const timeSelect = document.getElementById("pickup-time-select");

        if (pInput && this.originCity) pInput.value = formatCityLabel(this.originCity);
        if (dInput && this.destCity) dInput.value = formatCityLabel(this.destCity);
        if (dateInput && this.pickupDate) dateInput.value = this.pickupDate;
        if (timeSelect && this.pickupTime) timeSelect.value = this.pickupTime;
      } else {
        const pCache = localStorage.getItem("otb_passenger_cache");
        if (pCache) {
          Object.assign(this.passengerDetails, JSON.parse(pCache));
        }
      }
    } catch (e) {
      console.warn("Could not restore booking state:", e);
    }
  }

  setRentalMode(mode) {
    this.rentalMode = mode;
    this.withDriver = (mode === "with_driver");

    const btnWithout = document.getElementById("btn-rental-without-driver");
    const btnWith = document.getElementById("btn-rental-with-driver");
    const hint = document.getElementById("rental-rate-hint");

    if (btnWithout && btnWith) {
      if (mode === "without_driver") {
        btnWithout.classList.add("active");
        btnWithout.style.border = "1.5px solid #2563eb";
        btnWithout.style.background = "#eff6ff";
        btnWithout.style.color = "#1d4ed8";

        btnWith.classList.remove("active");
        btnWith.style.border = "1.5px solid #cbd5e1";
        btnWith.style.background = "#ffffff";
        btnWith.style.color = "#334155";

        if (hint) {
          const sedanPrice = this.activeFleetRates?.sedan?.rentalPrice || 2200;
          const suvPrice = this.activeFleetRates?.suv?.rentalPrice || 4000;
          hint.textContent = `Sedan ₹${sedanPrice.toLocaleString('en-IN')} • SUV ₹${suvPrice.toLocaleString('en-IN')} / Day (Self-Drive)`;
        }
      } else {
        btnWith.classList.add("active");
        btnWith.style.border = "1.5px solid #059669";
        btnWith.style.background = "#ecfdf5";
        btnWith.style.color = "#047857";

        btnWithout.classList.remove("active");
        btnWithout.style.border = "1.5px solid #cbd5e1";
        btnWithout.style.background = "#ffffff";
        btnWithout.style.color = "#334155";

        if (hint) {
          const sedanPrice = (this.activeFleetRates?.sedan?.rentalPrice || 2200) + (this.activeFleetRates?.sedan?.rentalDriverAllowance || 1000);
          const suvPrice = (this.activeFleetRates?.suv?.rentalPrice || 4000) + (this.activeFleetRates?.suv?.rentalDriverAllowance || 1000);
          hint.textContent = `Sedan ₹${sedanPrice.toLocaleString('en-IN')} • SUV ₹${suvPrice.toLocaleString('en-IN')} / Day (With Driver)`;
        }
      }
    }
    this.renderFleetCards();
  }

  async fetchFareConfig() {
    try {
      const res = await fetch("/api/fares/config");
      if (res.ok) {
        const data = await res.json();
        if (data && data.success && data.fleetRates) {
          this.activeFleetRates = data.fleetRates;
          this.activeSegmentFares = data.segmentFares;
          this.renderFleetCards();
          if (this.tripType === "rental" || this.tripType === "local") {
            this.setRentalMode(this.rentalMode || "without_driver");
          }
        }
      }
    } catch (e) {
      console.warn("Could not fetch remote fare config, fallback to defaults:", e);
    }
  }

  setDefaultDates() {
    const today = new Date();
    const formatYMD = (d) => {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${y}-${m}-${day}`;
    };
    this.pickupDate = formatYMD(today); // ONLY CURRENT DATE FILLED INITIALLY
    this.returnDate = "";

    const pickupDateInput = document.getElementById("pickup-date-input");
    const returnDateInput = document.getElementById("return-date-input");

    if (pickupDateInput) {
      pickupDateInput.value = this.pickupDate;
      pickupDateInput.min = formatYMD(today);
      pickupDateInput.addEventListener("change", (e) => {
        this.pickupDate = e.target.value;
      });
    }

    if (returnDateInput) {
      returnDateInput.value = this.returnDate;
      returnDateInput.min = formatYMD(today);
      returnDateInput.addEventListener("change", (e) => {
        this.returnDate = e.target.value;
      });
    }

    const timeSelect = document.getElementById("pickup-time-select");
    if (timeSelect) {
      timeSelect.addEventListener("change", (e) => {
        this.pickupTime = e.target.value;
      });
    }
  }

  /* ==========================================================================
     INTELLIGENT LOCATION RECOMMENDATIONS & AUTOCOMPLETE
     ========================================================================== */
  setupAutocomplete() {
    const pickupInput = document.getElementById("input-pickup");
    const dropInput = document.getElementById("input-drop");
    const pickupDropdown = document.getElementById("pickup-dropdown");
    const dropDropdown = document.getElementById("drop-dropdown");
    const clearPickupBtn = document.getElementById("btn-clear-pickup");
    const clearDropBtn = document.getElementById("btn-clear-drop");
    const swapBtn = document.getElementById("btn-swap-route");
    const gpsBtn = document.getElementById("btn-gps-pickup");
    const lblPickup = document.getElementById("lbl-pickup");
    const lblDrop = document.getElementById("lbl-drop");

    const setupInputEvents = (input, dropdown, type) => {
      if (!input || !dropdown) return;

      // Fast real-time keystroke filtering with micro-debounce
      let searchDebounceTimer = null;
      input.addEventListener("input", (e) => {
        clearTimeout(searchDebounceTimer);
        const val = e.target.value;
        searchDebounceTimer = setTimeout(() => {
          this.handleCitySearch(type, val.trim(), dropdown, false);
          this.autoResolveCityFromInput(type, val.trim(), false);
        }, 40);
      });

      input.addEventListener("change", (e) => {
        this.autoResolveCityFromInput(type, e.target.value.trim(), false);
      });

      input.addEventListener("blur", () => {
        setTimeout(() => {
          this.autoResolveCityFromInput(type, input.value.trim(), false);
        }, 200);
      });

      // Instant dropdown opening on focus or click
      input.addEventListener("focus", () => {
        if (type === "pickup" && dropDropdown) dropDropdown.style.display = "none";
        if (type === "drop" && pickupDropdown) pickupDropdown.style.display = "none";
        this.handleCitySearch(type, "", dropdown, true);
        try { input.select(); } catch(e) {}
      });

      input.addEventListener("click", () => {
        if (dropdown.style.display !== "block") {
          this.handleCitySearch(type, "", dropdown, true);
          try { input.select(); } catch(e) {}
        }
      });

      // Keyboard navigation
      input.addEventListener("keydown", (e) => {
        const items = dropdown.querySelectorAll(".autocomplete-item");
        if (!items.length || dropdown.style.display === "none") return;

        let activeIdx = -1;
        items.forEach((it, idx) => {
          if (it.classList.contains("active-item")) activeIdx = idx;
        });

        if (e.key === "ArrowDown") {
          e.preventDefault();
          const nextIdx = (activeIdx + 1) % items.length;
          items.forEach(it => it.classList.remove("active-item"));
          items[nextIdx].classList.add("active-item");
          items[nextIdx].scrollIntoView({ block: "nearest" });
        } else if (e.key === "ArrowUp") {
          e.preventDefault();
          const prevIdx = (activeIdx - 1 + items.length) % items.length;
          items.forEach(it => it.classList.remove("active-item"));
          items[prevIdx].classList.add("active-item");
          items[prevIdx].scrollIntoView({ block: "nearest" });
        } else if (e.key === "Enter") {
          e.preventDefault();
          if (activeIdx >= 0 && items[activeIdx]) {
            items[activeIdx].click();
          } else if (items.length > 0) {
            items[0].click();
          } else {
            this.autoResolveCityFromInput(type, input.value.trim(), true);
            dropdown.style.display = "none";
          }
        } else if (e.key === "Escape") {
          dropdown.style.display = "none";
        }
      });
    };

    if (pickupInput && pickupDropdown) {
      setupInputEvents(pickupInput, pickupDropdown, "pickup");
    }

    if (dropInput && dropDropdown) {
      setupInputEvents(dropInput, dropDropdown, "drop");
    }

    if (lblPickup && pickupInput) {
      lblPickup.addEventListener("click", () => pickupInput.focus());
    }

    if (lblDrop && dropInput) {
      lblDrop.addEventListener("click", () => dropInput.focus());
    }

    if (clearPickupBtn && pickupInput) {
      clearPickupBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        pickupInput.value = "";
        this.originCity = null;
        this.clearGpsLocatingUI();
        pickupInput.focus();
        this.handleCitySearch("pickup", "", pickupDropdown, true);
        this.calculateAndRenderFares();
      });
    }

    if (clearDropBtn && dropInput) {
      clearDropBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        dropInput.value = "";
        this.destCity = null;
        dropInput.focus();
        this.handleCitySearch("drop", "", dropDropdown, true);
        this.calculateAndRenderFares();
      });
    }

    if (swapBtn) {
      swapBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!this.originCity && !this.destCity) return;
        const temp = this.originCity;
        this.originCity = this.destCity;
        this.destCity = temp;

        const formatCityLabel = (c) => c ? `${c.name}${c.district && c.district !== c.name && c.type !== 'airport' ? ', ' + c.district : ''} (${c.hindiName || ''}), ${c.state}` : "";
        if (pickupInput) pickupInput.value = formatCityLabel(this.originCity);
        if (dropInput) dropInput.value = formatCityLabel(this.destCity);

        if (pickupDropdown) pickupDropdown.style.display = "none";
        if (dropDropdown) dropDropdown.style.display = "none";

        this.calculateAndRenderFares();
      });
    }

    if (gpsBtn) {
      gpsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.detectCurrentLocation(true);
      });
    }

    document.addEventListener("click", (e) => {
      if (!e.target.closest(".autocomplete-wrapper")) {
        if (pickupDropdown) pickupDropdown.style.display = "none";
        if (dropDropdown) dropDropdown.style.display = "none";
      }
    });
  }

  autoResolveCityFromInput(type, rawVal, updateInputFormatted = false) {
    if (!rawVal || rawVal.trim().length < 2) {
      if (type === "pickup") this.originCity = null;
      else this.destCity = null;
      this.updateCheckFareButtonState();
      return;
    }

    const q = rawVal.toLowerCase().replace(/[()[\]{}]/g, " ").trim();
    // Try exact or clean match
    let match = OTB_CITIES.find(c => c.name.toLowerCase() === q || c.id === q);
    if (!match) {
      match = OTB_CITIES.find(c => c.name.toLowerCase().startsWith(q) || (c.hindiName && c.hindiName === q));
    }
    if (!match && q.length >= 3) {
      match = OTB_CITIES.find(c => q.includes(c.name.toLowerCase()) || c.name.toLowerCase().includes(q) || (c.hindiName && q.includes(c.hindiName)));
    }

    if (match) {
      if (type === "pickup") {
        const changed = !this.originCity || this.originCity.id !== match.id;
        this.originCity = match;
        if (updateInputFormatted) {
          const pInput = document.getElementById("input-pickup");
          if (pInput) pInput.value = `${match.name}${match.district && match.district !== match.name && match.type !== 'airport' ? ', ' + match.district : ''} (${match.hindiName || ''}), ${match.state}`;
        }
        if (changed) {
          try { ApiClient.getCitiesDrop(match.name); } catch(e) {}
        }
      } else {
        this.destCity = match;
        if (updateInputFormatted) {
          const dInput = document.getElementById("input-drop");
          if (dInput) dInput.value = `${match.name}${match.district && match.district !== match.name && match.type !== 'airport' ? ', ' + match.district : ''} (${match.hindiName || ''}), ${match.state}`;
        }
      }

      const phoneInput = document.getElementById("input-fare-phone");
      const rawPhone = (phoneInput?.value || this.userPhone || "").replace(/\D/g, "");
      const hasValidPhone = rawPhone.length === 10 && /^[6-9]\d{9}$/.test(rawPhone);

      if (this.originCity && this.destCity && hasValidPhone) {
        this.isFareUnlocked = true;
        const section = document.getElementById("cab-selection-section");
        const mapSection = document.getElementById("route-map-section");
        if (section) {
          section.classList.remove("fare-section-closed");
          section.classList.add("fare-section-open");
        }
        if (mapSection) {
          mapSection.classList.remove("fare-section-closed");
          mapSection.classList.add("fare-section-open");
        }
        this.calculateAndRenderFares();
      } else {
        this.isFareUnlocked = false;
        const section = document.getElementById("cab-selection-section");
        const mapSection = document.getElementById("route-map-section");
        if (section) {
          section.classList.add("fare-section-closed");
          section.classList.remove("fare-section-open");
        }
        if (mapSection) {
          mapSection.classList.add("fare-section-closed");
          mapSection.classList.remove("fare-section-open");
        }
      }
      this.updateCheckFareButtonState();
    }
  }

  /* ==========================================================================
     GPS AUTOMATIC CURRENT LOCATION FETCHER & DISTANCE CALCULATOR
     ========================================================================== */
  calcHaversineDistance(lat1, lon1, lat2, lon2) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return 100;
    const R = 6371; // km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  }

  findNearestDistrict(lat, lng) {
    let nearest = null;
    let minDistance = Infinity;
    for (const city of OTB_CITIES) {
      if (city.lat && city.lng) {
        const d = this.calcHaversineDistance(lat, lng, city.lat, city.lng);
        if (d < minDistance) {
          minDistance = d;
          nearest = city;
        }
      }
    }
    return nearest;
  }

  detectCurrentLocation(autoFocusDrop = true) {
    const pickupInput = document.getElementById("input-pickup");
    const pickupDropdown = document.getElementById("pickup-dropdown");
    const pickupGroup = document.getElementById("group-pickup");
    const gpsBtn = document.getElementById("btn-gps-pickup");

    if (pickupGroup) pickupGroup.classList.add("gps-active");
    if (gpsBtn) gpsBtn.classList.add("gps-searching");

    if (!navigator.geolocation) {
      this.clearGpsLocatingUI();
      window.showToast("Geolocation is not supported by your browser", "info");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const nearest = this.findNearestDistrict(lat, lng) || OTB_CITIES.find(c => c.id === "patna") || OTB_CITIES[0];
        this.originCity = nearest;

        if (pickupInput) {
          pickupInput.value = `${nearest.name} (${nearest.hindiName}), ${nearest.state}`;
        }
        if (pickupDropdown) pickupDropdown.style.display = "none";
        this.clearGpsLocatingUI();
        window.showToast(`Location detected: ${nearest.name} (${nearest.hindiName})`, "success");

        this.calculateAndRenderFares();

        if (autoFocusDrop) {
          setTimeout(() => {
            const dropInput = document.getElementById("input-drop");
            const dropDropdown = document.getElementById("drop-dropdown");
            if (dropInput && !dropInput.value.trim()) {
              dropInput.focus();
              this.handleCitySearch("drop", "", dropDropdown, true);
            }
          }, 200);
        }
      },
      (err) => {
        console.warn("GPS detection skipped or denied:", err.message);
        this.clearGpsLocatingUI();
        window.showToast("Location access unavailable. Please choose your city from the list.", "info");
        if (pickupInput && pickupDropdown) {
          pickupInput.focus();
          this.handleCitySearch("pickup", "", pickupDropdown, true);
        }
      },
      { enableHighAccuracy: true, timeout: 5000, maximumAge: 300000 }
    );
  }

  fetchCurrentLocationAndFillPickup(autoFocusDrop = true) {
    return this.detectCurrentLocation(autoFocusDrop);
  }

  clearGpsLocatingUI() {
    const pickupGroup = document.getElementById("group-pickup");
    const gpsBtn = document.getElementById("btn-gps-pickup");
    if (pickupGroup) pickupGroup.classList.remove("gps-active");
    if (gpsBtn) gpsBtn.classList.remove("gps-searching");
  }

  fallbackDefaultPickup(autoFocusDrop = true, message = "") {
    this.clearGpsLocatingUI();
    if (!this.originCity) {
      this.originCity = OTB_CITIES.find(c => c.id === "patna") || OTB_CITIES[0];
      const pickupInput = document.getElementById("input-pickup");
      if (pickupInput) pickupInput.value = `${this.originCity.name} (${this.originCity.hindiName}), ${this.originCity.state}`;
    }
    if (message) window.showToast(message, "info");
    this.calculateAndRenderFares();

    if (autoFocusDrop) {
      setTimeout(() => {
        const dropInput = document.getElementById("input-drop");
        const dropDropdown = document.getElementById("drop-dropdown");
        if (dropInput) {
          dropInput.focus();
          this.handleCitySearch("drop", "", dropDropdown, true);
        }
      }, 200);
    }
  }

  /* ==========================================================================
     FAST, ACCURATE & PROFESSIONAL DROP & PICKUP RECOMMENDATION ENGINE
     ========================================================================== */
  handleCitySearch(type, query, dropdownEl, isFocus = false) {
    if (!dropdownEl) return;
    const lower = (query || "").trim().toLowerCase();

    // Clean vector SVG icon helper by location type (Zero emojis)
    const getCleanIconSvg = (c) => {
      if (c.type === "airport") {
        return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3.5c-.5-.5-2.5 0-4 1.5L13.5 8.5 5.3 6.7c-.8-.2-1.5.1-1.8.7l-.5.9c-.3.7 0 1.5.6 1.9l6.5 4.7-3.5 3.5-2.8-.9c-.4-.1-.8 0-1.1.3l-.4.4c-.3.3-.3.8 0 1.1l2.3 2.3c.3.3.8.3 1.1 0l.4-.4c.3-.3.4-.7.3-1.1l-.9-2.8 3.5-3.5 4.7 6.5c.4.6 1.2.9 1.9.6l.9-.5c.6-.3.9-1 .7-1.8z"/></svg>`;
      }
      if (c.type === "railway") {
        return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="16" rx="2"/><path d="M4 11h16"/><path d="M12 3v8"/><circle cx="8" cy="15" r="1"/><circle cx="16" cy="15" r="1"/><path d="M6 19l-2 3"/><path d="M18 19l2 3"/></svg>`;
      }
      if (c.type === "outstation") {
        return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>`;
      }
      if (c.type === "subdivision" || c.type === "town") {
        return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>`;
      }
      // Default: Official District Seat
      return `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M5 21V7l8-4v18M19 21V11l-6-3M9 9h1M9 13h1M9 17h1M15 13h1M15 17h1"/></svg>`;
    };

    // Category Type Badge Helper
    const getTypeBadge = (c) => {
      const label = c.typeLabel || (c.type === "subdivision" ? "Sub-Division" : (c.type === "district" ? "District HQ" : c.state));
      let cls = "badge-district";
      if (c.type === "airport") cls = "badge-airport";
      else if (c.type === "railway") cls = "badge-railway";
      else if (c.type === "subdivision") cls = "badge-subdivision";
      else if (c.type === "town") cls = "badge-town";
      else if (c.type === "outstation") cls = "badge-outstation";
      return `<span class="autocomplete-type-pill ${cls}">${label}</span>`;
    };

    // Keyword Match Highlighting (Clean, non-childish sapphire styling)
    const highlightMatchedWords = (text, searchWords) => {
      if (!text || !searchWords || !searchWords.length) return text || "";
      let output = text;
      const sorted = [...searchWords].sort((a, b) => b.length - a.length);
      sorted.forEach(w => {
        if (!w || w.length < 2) return;
        const reg = new RegExp(`(${w.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')})`, "gi");
        output = output.replace(reg, `<strong class="ac-match-highlight">$1</strong>`);
      });
      return output;
    };

    // Route distance & duration calculator
    const getRouteMeta = (dest) => {
      if (!this.originCity || !dest) return { dist: null, duration: null };
      if (this.originCity.id === dest.id) return { dist: 25, duration: "45 min" };

      const popular = OTB_POPULAR_ROUTES.find(r =>
        (r.fromId === this.originCity.id && r.toId === dest.id) ||
        (r.fromId === dest.id && r.toId === this.originCity.id)
      );
      if (popular) {
        return { dist: popular.distanceKm, duration: popular.duration };
      }

      if (this.originCity && this.originCity.lat && dest && dest.lat) {
        const d = this.calcHaversineDistance(this.originCity.lat, this.originCity.lng, dest.lat, dest.lng);
        const hours = (d / 48).toFixed(1);
        return { dist: d, duration: `~${hours}h` };
      }
      return { dist: null, duration: null };
    };

    // CASE 1: Real-time search with Multi-Word Keyword Matching & Non-Match Elimination
    const cleanLower = lower.replace(/[()[\]{}]/g, " ").replace(/\bbihar\b/gi, " ").trim();
    const searchWords = cleanLower.split(/[\s,]+/).filter(w => w.length > 0);

    if (searchWords.length > 0) {
      const scoredMatches = [];

      for (const c of OTB_CITIES) {
        let matchesAllWords = true;
        let score = 0;

        const cName = (c.name || "").toLowerCase();
        const cHindi = c.hindiName || "";
        const cDistrict = (c.district || "").toLowerCase();
        const cDivision = (c.division || "").toLowerCase();
        const cTag = (c.tag || "").toLowerCase();
        const cTypeLabel = (c.typeLabel || "").toLowerCase();
        const cAirport = (c.airport || "").toLowerCase();
        const cKeywords = Array.isArray(c.keywords) ? c.keywords.join(" ").toLowerCase() : "";

        for (const w of searchWords) {
          let wordMatched = false;

          // 1. Direct Name Match (Highest priority)
          if (cName === w) {
            wordMatched = true;
            score += 250;
          } else if (cName.startsWith(w)) {
            wordMatched = true;
            score += 180;
          } else if (cName.includes(" " + w) || cName.includes("(" + w) || cName.includes("/" + w)) {
            wordMatched = true;
            score += 140;
          } else if (cName.includes(w)) {
            wordMatched = true;
            score += 90;
          }

          // 2. Hindi Name Match
          if (cHindi.includes(w)) {
            wordMatched = true;
            score += 120;
          }

          // 3. Parent District Match (e.g. typing "patna" finds Danapur, Bihta, Barh)
          if (cDistrict === w) {
            wordMatched = true;
            score += 100;
          } else if (cDistrict.startsWith(w)) {
            wordMatched = true;
            score += 70;
          } else if (cDistrict.includes(w)) {
            wordMatched = true;
            score += 45;
          }

          // 4. Airport / Station code or label match
          if (cAirport && cAirport.includes(w)) {
            wordMatched = true;
            score += 110;
          }

          // 5. Keyword or Landmark Tag match
          if (cKeywords.includes(w) || cTag.includes(w) || cTypeLabel.includes(w)) {
            wordMatched = true;
            score += 65;
          }

          // 6. Division match (Only if query is longer than 2 letters)
          if (w.length > 2 && (cDivision.startsWith(w) || cDivision.includes(w))) {
            wordMatched = true;
            score += 30;
          }

          // STRICT ELIMINATION: If any search word doesn't match this candidate, eliminate it!
          if (!wordMatched) {
            matchesAllWords = false;
            break;
          }
        }

        if (matchesAllWords) {
          // Bonus scoring for relevant exact and popular matches
          if (cName === lower) score += 300;
          else if (cName.startsWith(lower)) score += 150;
          if (c.popular) score += 40;
          if (c.type === "district") score += 35;
          if (c.type === "airport" && (lower.includes("air") || lower.includes("port") || lower.includes("fly"))) score += 120;
          if (c.type === "railway" && (lower.includes("junc") || lower.includes("station") || lower.includes("rail"))) score += 120;

          scoredMatches.push({ item: c, score });
        }
      }

      // Sort by relevance score descending
      scoredMatches.sort((a, b) => b.score - a.score);
      const matches = scoredMatches.map(s => s.item);

      if (matches.length === 0) {
        dropdownEl.innerHTML = `
          <div class="autocomplete-no-match">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" style="margin: 0 auto 8px; color: var(--owc-text-muted);"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
            <div class="no-match-title">No location matching "${query}"</div>
            <div class="no-match-sub">Try entering a District (e.g. Patna, Gaya, Muzaffarpur) or Sub-Division (e.g. Danapur, Bihta, Rajgir, Sasaram, Hajipur, Raxaul)</div>
          </div>
        `;
        dropdownEl.style.display = "block";
        return;
      }

      dropdownEl.innerHTML = `
        <div class="autocomplete-group-header">
          <span>MATCHING LOCATIONS (${matches.length})</span>
          <span style="font-size: 10px; opacity: 0.8;">Use ↑ ↓ keys to navigate</span>
        </div>
        ${matches.slice(0, 15).map((c, idx) => {
          const meta = type === "drop" ? getRouteMeta(c) : { dist: null, duration: null };
          const districtLine = c.district && c.district !== c.name 
            ? `${c.typeLabel || 'Sub-Division'} • ${c.district} District`
            : `${c.typeLabel || 'District HQ'} • ${c.division} Division`;
          return `
            <div class="autocomplete-item ${idx === 0 ? 'active-item' : ''}" onclick="window.bookingManager.selectCity('${type}', '${c.id}')">
              <div class="autocomplete-item-left">
                <div class="autocomplete-item-icon ${c.type}">
                  ${getCleanIconSvg(c)}
                </div>
                <div class="autocomplete-item-meta">
                  <div class="autocomplete-item-name">
                    ${highlightMatchedWords(c.name, searchWords)} 
                    ${c.hindiName ? `<span class="ac-item-hindi">(${c.hindiName})</span>` : ''}
                  </div>
                  <div class="autocomplete-item-state">
                    ${districtLine}
                    ${c.tag ? ` &bull; <span class="ac-item-tag-text">${c.tag}</span>` : ''}
                  </div>
                </div>
              </div>
              <div class="autocomplete-item-right">
                ${getTypeBadge(c)}
                ${meta.dist ? `<span class="autocomplete-dist-badge">~${meta.dist} KM</span>` : ''}
                ${meta.duration ? `<span class="autocomplete-duration-text">${meta.duration}</span>` : ''}
              </div>
            </div>
          `;
        }).join("")}
      `;
      dropdownEl.style.display = "block";
      return;
    }

    // CASE 2: Pickup Dropdown on Focus (Initial Empty State)
    if (type === "pickup") {
      const popularDistricts = OTB_CITIES.filter(c => c.type === "district" && c.popular).slice(0, 7);
      const airports = OTB_CITIES.filter(c => c.type === "airport").slice(0, 3);
      const keySubdivisions = OTB_CITIES.filter(c => c.type === "subdivision" && c.popular).slice(0, 6);

      dropdownEl.innerHTML = `
        <div class="autocomplete-item current-loc-item" onclick="window.bookingManager.detectCurrentLocation(true)">
          <div class="autocomplete-item-left">
            <div class="autocomplete-item-icon icon-gps">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="2" x2="12" y2="6"/>
                <line x1="12" y1="18" x2="12" y2="22"/>
                <line x1="2" y1="12" x2="6" y2="12"/>
                <line x1="18" y1="12" x2="22" y2="12"/>
                <circle cx="12" cy="12" r="2.5" fill="currentColor"/>
              </svg>
            </div>
            <div>
              <div class="autocomplete-item-name" style="color: #0070f3; font-weight: 800;">Use Current GPS Location</div>
              <div class="autocomplete-item-state">Detect exact doorstep position in Bihar</div>
            </div>
          </div>
          <span class="autocomplete-dist-badge" style="background: rgba(0, 112, 243, 0.1); color: #0070f3;">GPS AUTO</span>
        </div>

        <div class="autocomplete-group-header">
          <span>POPULAR DISTRICT HEADQUARTERS</span>
        </div>
        ${popularDistricts.map(c => `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('pickup', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon district">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name} <span class="ac-item-hindi">(${c.hindiName})</span></div>
                <div class="autocomplete-item-state">${c.division} Division • ${c.tag || 'Bihar'}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
            </div>
          </div>
        `).join("")}

        <div class="autocomplete-group-header" style="border-top: 1px solid var(--owc-border-light);">
          <span>COMMERCIAL AIRPORT TERMINALS</span>
        </div>
        ${airports.map(c => `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('pickup', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon airport">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name}</div>
                <div class="autocomplete-item-state">${c.tag}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
            </div>
          </div>
        `).join("")}

        <div class="autocomplete-group-header" style="border-top: 1px solid var(--owc-border-light);">
          <span>KEY SUB-DIVISIONS & TEHSILS</span>
        </div>
        ${keySubdivisions.map(c => `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('pickup', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon subdivision">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name} <span class="ac-item-hindi">(${c.hindiName})</span></div>
                <div class="autocomplete-item-state">${c.district} District &bull; ${c.tag}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
            </div>
          </div>
        `).join("")}
      `;
      dropdownEl.style.display = "block";
      return;
    }

    // CASE 3: Drop Dropdown on Focus (Initial Empty State)
    const originId = this.originCity ? this.originCity.id : "patna";
    const originName = this.originCity ? this.originCity.name : "Patna";

    let popularDests = [];
    const knownRoutes = OTB_POPULAR_ROUTES.filter(r => r.fromId === originId || r.toId === originId);
    if (knownRoutes.length > 0) {
      popularDests = knownRoutes.map(r => {
        const targetId = r.fromId === originId ? r.toId : r.fromId;
        return OTB_CITIES.find(c => c.id === targetId);
      }).filter(Boolean);
    }
    const fallbackHubs = OTB_CITIES.filter(c => c.popular && c.id !== originId && !popularDests.some(p => p.id === c.id));
    const topDests = [...popularDests, ...fallbackHubs].slice(0, 6);
    const airports = OTB_CITIES.filter(c => c.type === "airport" && c.id !== originId).slice(0, 3);
    const subDivisions = OTB_CITIES.filter(c => c.type === "subdivision" && c.popular && c.id !== originId).slice(0, 4);
    const outstations = OTB_CITIES.filter(c => c.type === "outstation" && c.id !== originId).slice(0, 4);

    dropdownEl.innerHTML = `
      <div class="autocomplete-group-header">
        <span>RECOMMENDED DESTINATIONS FROM ${originName.toUpperCase()}</span>
      </div>
      ${topDests.map(c => {
        const meta = getRouteMeta(c);
        return `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('drop', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon ${c.type}">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name} <span class="ac-item-hindi">(${c.hindiName})</span></div>
                <div class="autocomplete-item-state">${c.district ? c.district + ' District' : c.division + ' Division'} • ${c.tag || 'Major City'}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
              ${meta.dist ? `<span class="autocomplete-dist-badge">~${meta.dist} KM</span>` : ''}
              ${meta.duration ? `<span class="autocomplete-duration-text">${meta.duration}</span>` : ''}
            </div>
          </div>
        `;
      }).join("")}

      <div class="autocomplete-group-header" style="border-top: 1px solid var(--owc-border-light);">
        <span>POPULAR SUB-DIVISIONS & TOWNS</span>
      </div>
      ${subDivisions.map(c => {
        const meta = getRouteMeta(c);
        return `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('drop', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon subdivision">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name} <span class="ac-item-hindi">(${c.hindiName})</span></div>
                <div class="autocomplete-item-state">${c.district} District • ${c.tag}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
              ${meta.dist ? `<span class="autocomplete-dist-badge">~${meta.dist} KM</span>` : ''}
              ${meta.duration ? `<span class="autocomplete-duration-text">${meta.duration}</span>` : ''}
            </div>
          </div>
        `;
      }).join("")}

      <div class="autocomplete-group-header" style="border-top: 1px solid var(--owc-border-light);">
        <span>AIRPORTS & FLIGHT TERMINALS</span>
      </div>
      ${airports.map(c => {
        const meta = getRouteMeta(c);
        return `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('drop', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon airport">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name}</div>
                <div class="autocomplete-item-state">${c.district} District • 24x7 Airport Drop</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
              ${meta.dist ? `<span class="autocomplete-dist-badge">~${meta.dist} KM</span>` : ''}
              ${meta.duration ? `<span class="autocomplete-duration-text">${meta.duration}</span>` : ''}
            </div>
          </div>
        `;
      }).join("")}

      <div class="autocomplete-group-header" style="border-top: 1px solid var(--owc-border-light);">
        <span>OUTSTATION & INTERCITY CORRIDORS</span>
      </div>
      ${outstations.map(c => {
        const meta = getRouteMeta(c);
        return `
          <div class="autocomplete-item" onclick="window.bookingManager.selectCity('drop', '${c.id}')">
            <div class="autocomplete-item-left">
              <div class="autocomplete-item-icon outstation">
                ${getCleanIconSvg(c)}
              </div>
              <div class="autocomplete-item-meta">
                <div class="autocomplete-item-name">${c.name} <span class="ac-item-hindi">(${c.hindiName})</span></div>
                <div class="autocomplete-item-state">${c.state} • ${c.tag || 'Intercity Express'}</div>
              </div>
            </div>
            <div class="autocomplete-item-right">
              ${getTypeBadge(c)}
              ${meta.dist ? `<span class="autocomplete-dist-badge">~${meta.dist} KM</span>` : ''}
              ${meta.duration ? `<span class="autocomplete-duration-text">${meta.duration}</span>` : ''}
            </div>
          </div>
        `;
      }).join("")}
    `;

    dropdownEl.style.display = "block";
  }

  selectCity(type, cityId) {
    const city = OTB_CITIES.find(c => c.id === cityId);
    if (!city) return;

    const formattedName = `${city.name}${city.district && city.district !== city.name && city.type !== 'airport' ? ', ' + city.district : ''} (${city.hindiName || ''}), ${city.state}`;

    if (type === "pickup") {
      this.originCity = city;
      const input = document.getElementById("input-pickup");
      if (input) input.value = formattedName;
      const dd = document.getElementById("pickup-dropdown");
      if (dd) dd.style.display = "none";
      this.clearGpsLocatingUI();

      // Automatically prefetch connected drop cities for this origin
      try { ApiClient.getCitiesDrop(city.name); } catch(e) {}

      // If destination was identical to origin, reset destination
      if (this.destCity && (this.destCity.id === city.id || this.destCity.name.toLowerCase() === city.name.toLowerCase())) {
        this.destCity = null;
        const dropInput = document.getElementById("input-drop");
        if (dropInput) dropInput.value = "";
      }

      // Smoothly transition to Drop if drop is currently empty
      const dropInput = document.getElementById("input-drop");
      if (dropInput && !dropInput.value.trim()) {
        setTimeout(() => {
          dropInput.focus();
          const dropDropdown = document.getElementById("drop-dropdown");
          this.handleCitySearch("drop", "", dropDropdown, true);
        }, 150);
      }
    } else {
      this.destCity = city;
      const input = document.getElementById("input-drop");
      if (input) input.value = formattedName;
      const dd = document.getElementById("drop-dropdown");
      if (dd) dd.style.display = "none";

      const phoneInput = document.getElementById("input-fare-phone");
      if (phoneInput && !phoneInput.value.trim()) {
        setTimeout(() => {
          phoneInput.focus();
        }, 200);
      }
    }

    const phoneInput = document.getElementById("input-fare-phone");
    const rawPhone = (phoneInput?.value || this.userPhone || "").replace(/\D/g, "");
    const hasValidPhone = rawPhone.length === 10 && /^[6-9]\d{9}$/.test(rawPhone);

    const isRental = (this.tripType === "rental" || this.tripType === "local");
    if (((this.originCity && this.destCity) || (this.originCity && isRental)) && hasValidPhone) {
      this.isFareUnlocked = true;
      const section = document.getElementById("cab-selection-section");
      const mapSection = document.getElementById("route-map-section");
      if (section) {
        section.classList.remove("fare-section-closed");
        section.classList.add("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.remove("fare-section-closed");
        mapSection.classList.add("fare-section-open");
      }
      this.calculateAndRenderFares();
    } else {
      this.isFareUnlocked = false;
      const section = document.getElementById("cab-selection-section");
      const mapSection = document.getElementById("route-map-section");
      if (section) {
        section.classList.add("fare-section-closed");
        section.classList.remove("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.add("fare-section-closed");
        mapSection.classList.remove("fare-section-open");
      }
    }
    this.updateCheckFareButtonState();
  }

  /* ==========================================================================
     EVENT LISTENERS & TAB CONTROLLERS
     ========================================================================== */
  setupEventListeners() {
    const tabBtns = document.querySelectorAll(".trip-tab-btn");
    tabBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        tabBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        this.tripType = btn.getAttribute("data-trip");
        this.updateTripTypeUI();
        this.calculateAndRenderFares();
      });
    });

    const localPkgSelect = document.getElementById("local-package-select");
    if (localPkgSelect) {
      localPkgSelect.addEventListener("change", (e) => {
        this.localPackageId = e.target.value;
        this.calculateAndRenderFares();
      });
    }



    // Phone Input for Fare Verification & Direct Helpdesk Transfer (Live Validation & Clear)
    const phoneInput = document.getElementById("input-fare-phone");
    const phoneGroup = document.getElementById("phone-check-group");
    const phoneClearBtn = document.getElementById("phone-input-clear-btn");
    if (phoneInput) {
      const handlePhoneInput = () => {
        const val = phoneInput.value.replace(/\D/g, "");
        phoneInput.value = val;
        if (phoneGroup) {
          phoneGroup.classList.toggle("has-value", val.length > 0);
          const isValid = val.length === 10 && /^[6-9]\d{9}$/.test(val);
          phoneGroup.classList.toggle("is-valid", isValid);
          phoneGroup.style.borderColor = "";
          phoneGroup.style.boxShadow = "";
          if (isValid) {
            this.userPhone = val;
            this.passengerDetails.phone = `+91 ${val}`;
            try { localStorage.setItem("oneway_fare_phone", val); } catch (e) {}

            if (!this.originCity) {
              const pickupInput = document.getElementById("input-pickup");
              const pVal = (pickupInput?.value || "Patna").trim();
              this.originCity = OTB_CITIES.find(c => c.name.toLowerCase() === pVal.toLowerCase() || c.id === pVal.toLowerCase()) || { id: "patna", name: pVal || "Patna" };
            }
            if (!this.destCity) {
              const dropInput = document.getElementById("input-drop");
              const dVal = (dropInput?.value || "Gaya").trim();
              this.destCity = OTB_CITIES.find(c => c.name.toLowerCase() === dVal.toLowerCase() || c.id === dVal.toLowerCase()) || { id: "gaya", name: dVal || "Gaya" };
            }

            this.transferLeadToHelpdesk(val, true, { source: "Homepage Phone Entered" });
          }
        }
        this.updateCheckFareButtonState();
      };

      phoneInput.addEventListener("input", handlePhoneInput);

      if (phoneClearBtn) {
        phoneClearBtn.addEventListener("click", () => {
          phoneInput.value = "";
          handlePhoneInput();
          phoneInput.focus();
        });
      }

      phoneInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          this.handleCheckFare();
        }
      });
    }

    const checkFareBtn = document.getElementById("btn-check-fare");
    if (checkFareBtn) {
      checkFareBtn.addEventListener("click", () => {
        this.handleCheckFare();
      });
    }

    this.updateCheckFareButtonState();
  }

  updateCheckFareButtonState() {
    const btn = document.getElementById("btn-check-fare");
    if (!btn) return;

    const pickupInput = document.getElementById("input-pickup");
    const dropInput = document.getElementById("input-drop");
    const phoneInput = document.getElementById("input-fare-phone");

    const hasPickup = Boolean(this.originCity || (pickupInput && pickupInput.value.trim().length > 1));
    const hasDrop = Boolean(this.destCity || (dropInput && dropInput.value.trim().length > 1));
    const rawPhone = (phoneInput?.value || this.userPhone || "").replace(/\D/g, "");
    const hasPhone = rawPhone.length === 10 && /^[6-9]\d{9}$/.test(rawPhone);

    // Ready only when pickup, drop AND valid phone are provided
    const isReady = hasPickup && hasDrop && hasPhone;

    if (isReady) {
      btn.classList.add("ready");
      btn.setAttribute("title", "Calculate fares & view cab availability");
      btn.innerHTML = `
        <span>Check Fares &amp; Availability</span>
        <svg class="btn-check-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
          <line x1="5" y1="12" x2="19" y2="12"></line>
          <polyline points="12 5 19 12 12 19"></polyline>
        </svg>
      `;
    } else if (hasPickup && hasDrop && !hasPhone) {
      btn.classList.remove("ready");
      btn.setAttribute("title", "Enter mobile number to view fares");
      btn.innerHTML = `
        <span>Enter Mobile to View Fares</span>
        <svg class="btn-check-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
      `;
    } else {
      btn.classList.remove("ready");
      btn.setAttribute("title", "Enter pickup, drop and mobile to calculate fare");
      btn.innerHTML = `
        <span>Check Fares &amp; Availability</span>
        <svg class="btn-check-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
      `;
    }
  }

  handleCheckFare(silent = false) {
    const pickupInput = document.getElementById("input-pickup");
    const dropInput = document.getElementById("input-drop");
    const phoneInput = document.getElementById("input-fare-phone");

    // 1. Resolve & Validate Pickup Location
    if (pickupInput && pickupInput.value.trim()) {
      const q = pickupInput.value.trim().toLowerCase().replace(/[()[\]{}]/g, " ");
      if (!this.originCity || (!pickupInput.value.toLowerCase().includes(this.originCity.name.toLowerCase()) && !this.originCity.name.toLowerCase().includes(q))) {
        this.originCity = OTB_CITIES.find(c =>
          c.name.toLowerCase() === q ||
          c.id === q ||
          c.name.toLowerCase().startsWith(q) ||
          q.includes(c.name.toLowerCase()) ||
          c.name.toLowerCase().includes(q) ||
          (c.hindiName && (q.includes(c.hindiName) || c.hindiName.includes(q)))
        ) || null;
      }
    }
    if (!this.originCity) {
      if (pickupInput) {
        const parent = pickupInput.closest(".input-field-group");
        if (parent) {
          parent.classList.add("shake-error");
          setTimeout(() => parent.classList.remove("shake-error"), 500);
        }
        pickupInput.focus();
        const dd = document.getElementById("pickup-dropdown");
        this.handleCitySearch("pickup", "", dd, true);
      }
      if (!silent) window.showToast("Please enter or select a Pickup District/City", "warning");
      return false;
    }

    // 2. Resolve & Validate Drop Location
    if (dropInput && dropInput.value.trim()) {
      const q = dropInput.value.trim().toLowerCase().replace(/[()[\]{}]/g, " ");
      if (!this.destCity || (!dropInput.value.toLowerCase().includes(this.destCity.name.toLowerCase()) && !this.destCity.name.toLowerCase().includes(q))) {
        this.destCity = OTB_CITIES.find(c =>
          c.name.toLowerCase() === q ||
          c.id === q ||
          c.name.toLowerCase().startsWith(q) ||
          q.includes(c.name.toLowerCase()) ||
          c.name.toLowerCase().includes(q) ||
          (c.hindiName && (q.includes(c.hindiName) || c.hindiName.includes(q)))
        ) || null;
      }
    }
    if (!this.destCity) {
      if (dropInput) {
        const parent = dropInput.closest(".input-field-group");
        if (parent) {
          parent.classList.add("shake-error");
          setTimeout(() => parent.classList.remove("shake-error"), 500);
        }
        dropInput.focus();
        const dd = document.getElementById("drop-dropdown");
        this.handleCitySearch("drop", "", dd, true);
      }
      if (!silent) window.showToast("Please enter or select a Drop District/City", "warning");
      return false;
    }

    // 3. Optional Phone capture at fare inquiry (silently captures inquiry if entered)
    let phoneToRecord = "";
    if (phoneInput && phoneInput.value) {
      phoneToRecord = phoneInput.value.trim().replace(/\D/g, "");
    }
    if (!phoneToRecord && this.userPhone) {
      phoneToRecord = this.userPhone.replace(/\D/g, "");
    }
    if (!phoneToRecord && window.currentUser && window.currentUser.phone) {
      phoneToRecord = window.currentUser.phone.replace(/\D/g, "");
    }
    if (!phoneToRecord) {
      const cachedPhone = localStorage.getItem("oneway_fare_phone");
      if (cachedPhone) phoneToRecord = cachedPhone.replace(/\D/g, "");
    }

    if (phoneToRecord.length > 10) {
      phoneToRecord = phoneToRecord.slice(-10);
    }

    if (phoneToRecord && phoneToRecord.length === 10 && /^[6-9]\d{9}$/.test(phoneToRecord)) {
      const clean10 = phoneToRecord;
      this.userPhone = clean10;
      this.passengerDetails.phone = `+91 ${clean10}`;
      localStorage.setItem("oneway_fare_phone", clean10);
      this.transferLeadToHelpdesk(clean10, true, { source: "Check Fares & Availability Button" });
    }

    // 4. Open and reveal Fare Details Section & Map Section
    this.isFareUnlocked = true;
    const section = document.getElementById("cab-selection-section");
    const mapSection = document.getElementById("route-map-section");

    if (section) {
      section.classList.remove("fare-section-closed");
      section.classList.add("fare-section-open");
    }
    if (mapSection) {
      mapSection.classList.remove("fare-section-closed");
      mapSection.classList.add("fare-section-open");
    }

    this.calculateAndRenderFares();

    if (window.onewayMap && window.onewayMap.map) {
      setTimeout(() => {
        window.onewayMap.map.invalidateSize();
      }, 250);
    }

    if (section && !silent) {
      setTimeout(() => {
        const topPos = section.getBoundingClientRect().top + window.pageYOffset - 80;
        window.scrollTo({ top: Math.max(0, topPos), behavior: "smooth" });
      }, 50);
      window.showToast(`Outstation Fares Calculated: ${this.originCity.name} to ${this.destCity.name}`, "success");
      history.pushState({ step: "cabs" }, "", "#cabs");
      this.saveState();
    }

    return true;
  }

  resetBookingForm() {
    this.originCity = null;
    this.destCity = null;
    this.userPhone = "";

    const pickupInput = document.getElementById("input-pickup");
    const dropInput = document.getElementById("input-drop");
    const phoneInput = document.getElementById("input-fare-phone");
    const pickupDropdown = document.getElementById("pickup-dropdown");
    const dropDropdown = document.getElementById("drop-dropdown");
    const phoneGroup = document.getElementById("phone-check-group");

    if (pickupInput) pickupInput.value = "";
    if (dropInput) dropInput.value = "";
    if (phoneInput) {
      phoneInput.value = "";
      phoneInput.blur();
    }
    if (pickupDropdown) pickupDropdown.style.display = "none";
    if (dropDropdown) dropDropdown.style.display = "none";
    if (phoneGroup) {
      phoneGroup.classList.remove("has-value", "is-valid");
      phoneGroup.style.borderColor = "";
      phoneGroup.style.boxShadow = "";
    }
    this.updateCheckFareButtonState();

    // Reset date to today's current date only
    const today = new Date();
    const formatYMD = (d) => {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${y}-${m}-${day}`;
    };
    this.pickupDate = formatYMD(today);
    const pickupDateInput = document.getElementById("pickup-date-input");
    if (pickupDateInput) pickupDateInput.value = this.pickupDate;

    localStorage.removeItem("oneway_fare_phone");
  }

  async transferLeadToHelpdesk(phone, silent = false, extra = {}) {
    const rawWa = window.currentPlatformSettings?.cleanWhatsapp || this.dynamicPaymentConfig?.cleanWhatsapp || "917281851011";
    const helpdeskNumber = rawWa.length === 10 ? `91${rawWa}` : rawWa;
    const clean10 = (phone || "").replace(/\D/g, "").slice(-10);
    if (!clean10 || clean10.length < 10) return;

    const pFormat = `+91 ${clean10}`;

    const origName = this.originCity ? this.originCity.name : "Patna";
    const destName = this.destCity ? this.destCity.name : "Gaya";

    // Calculate rates for quick quote preview
    const hatchFleet = OTB_FLEET.find(f => f.id === "hatchback") || OTB_FLEET[0];
    const sedanFleet = OTB_FLEET.find(f => f.id === "sedan") || OTB_FLEET[1];
    const suvFleet = OTB_FLEET.find(f => f.id === "suv") || OTB_FLEET[3];

    let hatchPrice = Math.round(this.calculatedDistanceKm * hatchFleet.ratePerKm);
    hatchPrice = Math.max(hatchPrice, 1698);
    let sedanPrice = Math.round(this.calculatedDistanceKm * sedanFleet.ratePerKm);
    sedanPrice = Math.max(sedanPrice, 2198);
    let suvPrice = Math.round(this.calculatedDistanceKm * suvFleet.ratePerKm);
    suvPrice = Math.max(suvPrice, 3398);

    const leadData = {
      phone: pFormat,
      rawPhone: clean10,
      cleanPhone: clean10,
      passengerName: extra.passengerName || this.passengerDetails.name || window.currentUser?.name || "Fare Check Visitor",
      originCity: origName,
      destCity: destName,
      tripType: this.tripType || "oneway",
      pickupDate: this.pickupDate || new Date().toISOString().split("T")[0],
      pickupTime: this.pickupTime || "10:00 AM",
      distanceKm: this.calculatedDistanceKm || 100,
      duration: this.calculatedDuration || "2h",
      selectedCab: extra.selectedCab || this.selectedCabId || "sedan",
      cabPrice: Number(extra.cabPrice || (extra.selectedCab === 'suv' ? suvPrice : (extra.selectedCab === 'hatchback' ? hatchPrice : sedanPrice))),
      estFareHatch: hatchPrice,
      estFareSedan: sedanPrice,
      estFareSuv: suvPrice,
      source: extra.source || "Check Fare & Availability",
      helpdeskWhatsApp: `+${helpdeskNumber}`,
      createdAt: new Date().toISOString()
    };

    // 1. Dispatch lead to server API and Admin Desk in background
    try {
      if (window.ApiClient && ApiClient.sendLead) {
        await ApiClient.sendLead(leadData);
      }
    } catch (err) {
      console.warn("Lead recorded locally:", err);
    }

    // 2. Prepare Helpdesk WhatsApp inquiry text for manual action
    const waText = 
      `*New Fare Inquiry - OneWayTaxiBihar*\n\n` +
      `*Customer Mobile:* ${pFormat}\n` +
      `*Route:* ${origName} → ${destName} (${(this.tripType || 'oneway').toUpperCase()})\n` +
      `*Date & Time:* ${leadData.pickupDate} at ${leadData.pickupTime}\n` +
      `*Distance:* ${leadData.distanceKm} KM (~${leadData.duration})\n` +
      `*Estimated Rates (Toll & GST incl.):*\n` +
      `  • Hatchback: ₹${hatchPrice.toLocaleString('en-IN')}\n` +
      `  • Prime Sedan: ₹${sedanPrice.toLocaleString('en-IN')}\n` +
      `  • Family SUV: ₹${suvPrice.toLocaleString('en-IN')}\n\n` +
      `Please confirm available cab & connect with customer.`;

    const waUrl = `https://wa.me/${helpdeskNumber}?text=${encodeURIComponent(waText)}`;
    this.currentWhatsAppLeadUrl = waUrl;
  }

  updateRouteBarHelpdeskConnect(phone, waUrl) {
    // Pure silent operation - do not inject notification banner to customer
    return;
  }

  updateTripTypeUI() {
    const returnDateRow = document.getElementById("return-date-row");
    const localPkgRow = document.getElementById("local-pkg-row");
    const rentalOptionsRow = document.getElementById("rental-options-row");
    const airportRow = document.getElementById("airport-details-row");
    const dropWrapper = document.getElementById("input-drop")?.closest(".autocomplete-wrapper");
    const swapBtn = document.getElementById("btn-swap-route");
    const lblDrop = document.getElementById("lbl-drop");

    const isRental = (this.tripType === "rental" || this.tripType === "local");

    if (returnDateRow) returnDateRow.style.display = this.tripType === "roundtrip" ? "block" : "none";
    if (rentalOptionsRow) rentalOptionsRow.style.display = isRental ? "block" : "none";
    if (localPkgRow) localPkgRow.style.display = "none";
    if (airportRow) airportRow.style.display = this.tripType === "airport" ? "block" : "none";

    if (isRental) {
      if (dropWrapper) dropWrapper.style.display = "none";
      if (swapBtn) swapBtn.style.display = "none";
      this.setRentalMode(this.rentalMode || "without_driver");
    } else {
      if (dropWrapper) dropWrapper.style.display = "block";
      if (swapBtn) swapBtn.style.display = "flex";
      if (lblDrop) {
        lblDrop.textContent = this.tripType === "airport" ? "AIRPORT TERMINAL / DROP" : "DROP DISTRICT / CITY";
      }
    }
  }

  /* ==========================================================================
     DYNAMIC ROUTE & FARE CALCULATION MATRIX
     ========================================================================== */
  calculateAndRenderFares() {
    const isRental = (this.tripType === "rental" || this.tripType === "local");
    if (!this.originCity || (!this.destCity && !isRental)) {
      this.calculatedDistanceKm = isRental ? 80 : 100;
      this.calculatedDuration = isRental ? "8 Hours" : "2h 00m";
      this.calculatedToll = 0;

      const displayRoute = document.getElementById("rf-display-route");
      const distBadge = document.getElementById("rf-dist-badge");
      const timeBadge = document.getElementById("rf-time-badge");
      const tollBadge = document.getElementById("rf-toll-badge");

      if (displayRoute) {
        if (isRental) {
          const pName = this.originCity ? this.originCity.name : "Select City";
          const mText = (this.rentalMode === "with_driver" || this.withDriver) ? "With Verified Chauffeur" : "Self-Drive Rental";
          displayRoute.innerHTML = `<span>Car Rental: <strong>${pName}</strong> (${mText} • 8 Hr / 80 KM)</span>`;
        } else if (this.originCity && !this.destCity) {
          displayRoute.innerHTML = `<span>Pickup: <strong>${this.originCity.name}</strong> → (Select Drop District)</span>`;
        } else if (!this.originCity && this.destCity) {
          displayRoute.innerHTML = `<span>(Select Pickup District) → Drop: <strong>${this.destCity.name}</strong></span>`;
        } else {
          displayRoute.innerHTML = `<span>Select Pickup & Drop District above to calculate live fare</span>`;
        }
      }

      if (distBadge) distBadge.textContent = isRental ? "80 KM / Day Included" : "Bihar Fixed Rates";
      if (timeBadge) timeBadge.textContent = isRental ? "8 Hours Daily" : "Instant Booking";
      if (tollBadge) tollBadge.textContent = isRental ? ((this.rentalMode === "with_driver" || this.withDriver) ? "Chauffeur & GST Included" : "Self-Drive Fixed Rate") : "Toll & GST Included";

      this.renderFleetCards();
      this.updateCheckFareButtonState();
      return;
    }

    const knownRoute = OTB_POPULAR_ROUTES.find(r => 
      (r.fromId === this.originCity.id && r.toId === this.destCity.id) ||
      (r.fromId === this.destCity.id && r.toId === this.originCity.id)
    );

    if (knownRoute) {
      this.calculatedDistanceKm = knownRoute.distanceKm;
      this.calculatedDuration = knownRoute.duration;
      this.calculatedToll = knownRoute.toll;
    } else {
      // Calculate curved highway distance
      const dLat = (this.destCity.lat - this.originCity.lat) * Math.PI / 180;
      const dLng = (this.destCity.lng - this.originCity.lng) * Math.PI / 180;
      const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(this.originCity.lat * Math.PI / 180) * Math.cos(this.destCity.lat * Math.PI / 180) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const rawKm = 6371 * c;
      this.calculatedDistanceKm = Math.max(40, Math.round(rawKm * 1.30));
      
      const speedKmH = 48; // Standard Bihar highway average with Setu/bridges
      const totalMin = Math.round((this.calculatedDistanceKm / speedKmH) * 60);
      const hrs = Math.floor(totalMin / 60);
      const mins = totalMin % 60;
      this.calculatedDuration = `${hrs}h ${mins}m`;
      this.calculatedToll = Math.round(this.calculatedDistanceKm * 1.1);
    }

    // Update Route Bar
    const displayRoute = document.getElementById("rf-display-route");
    const distBadge = document.getElementById("rf-dist-badge");
    const timeBadge = document.getElementById("rf-time-badge");
    const tollBadge = document.getElementById("rf-toll-badge");

    if (displayRoute) {
      if (this.tripType === "rental" || this.tripType === "local") {
        const modeDesc = (this.rentalMode === "with_driver" || this.withDriver) ? "With Verified Chauffeur" : "Self-Drive Rental";
        displayRoute.innerHTML = `<span>Car Rental: <strong>${this.originCity.name}</strong> (${modeDesc} • 8 Hr / 80 KM)</span>`;
      } else if (this.tripType === "roundtrip") {
        displayRoute.innerHTML = `<span><strong>${this.originCity.name}</strong> (${this.originCity.hindiName}) ⇄ <strong>${this.destCity.name}</strong> (${this.destCity.hindiName}) <span style="color: var(--owc-primary); font-weight: 700; margin-left: 6px;">(Round-Trip)</span></span>`;
      } else if (this.tripType === "airport") {
        displayRoute.innerHTML = `<span><strong>${this.originCity.name}</strong> → <strong>Airport Transfer</strong></span>`;
      } else {
        displayRoute.innerHTML = `<span><strong>${this.originCity.name}</strong> (${this.originCity.hindiName}) → <strong>${this.destCity.name}</strong> (${this.destCity.hindiName}) <span style="color: #059669; font-weight: 700; margin-left: 6px;">(Zero Return Fare)</span></span>`;
      }
    }

    if (distBadge) distBadge.textContent = (this.tripType === "rental" || this.tripType === "local") ? "80 KM / Day Included" : `${this.calculatedDistanceKm} KM Highway Route`;
    if (timeBadge) timeBadge.textContent = (this.tripType === "rental" || this.tripType === "local") ? "8 Hours Daily" : `~${this.calculatedDuration}`;
    if (tollBadge) tollBadge.textContent = (this.tripType === "rental" || this.tripType === "local") ? ((this.rentalMode === "with_driver" || this.withDriver) ? "Chauffeur & GST Included" : "Self-Drive Fixed Rate") : "Tolls, Fastag & GST Included";

    // Render Fleet Cards
    this.renderFleetCards();

    // Update Leaflet Map Polyline
    if (window.onewayMap) {
      window.onewayMap.updateRoute(this.originCity, this.destCity, this.calculatedDistanceKm);
    }
    this.updateCheckFareButtonState();

    // Fetch and display 2026 AI Mobility Intelligence
    this.fetchAiIntelligence();
  }

  async fetchAiIntelligence() {
    const strip = document.getElementById("ai-demand-strip");
    const textEl = document.getElementById("ai-demand-text");
    if (!strip || !textEl || !this.originCity || !this.destCity) return;

    strip.style.display = "inline-flex";
    textEl.textContent = "AI Demand Index: Analyzing highway demand & eco emissions...";

    try {
      const aiData = await ApiClient.getAiIntelligence({
        origin: this.originCity.name,
        destination: this.destCity.name,
        tripType: this.tripType
      });

      if (aiData && aiData.success) {
        textEl.innerHTML = `
          <strong>AI Demand Index: ${aiData.demandIndex}/100</strong> (${aiData.demandLevel || 'Optimal Booking Window'}) • 
          <strong>Eco-Save:</strong> ~${aiData.carbonSavedKg || 16} kg CO₂ vs empty return • 
          ${aiData.explanation || ''}
        `;
      }
    } catch (e) {
      console.warn("AI intelligence fetch skip:", e);
      strip.style.display = "none";
    }
  }

  renderFleetCards() {
    const container = document.getElementById("cab-cards-grid");
    if (!container) return;

    const isRental = (this.tripType === "rental" || this.tripType === "local");
    const rates = this.activeFleetRates || {};

    container.innerHTML = OTB_FLEET.map(fleet => {
      let finalPrice = 0;
      let savings = 0;
      let priceNote = "Fixed (Toll, GST & Allowance incl.)";
      let savingsText = "Saved ~₹1,500 vs Return Cab";

      if (isRental) {
        const tierRate = rates[fleet.id] || {};
        const baseRental = Number(tierRate.rentalPrice) || Number(fleet.rentalPrice) || (
          fleet.id === "sedan" ? 2200 :
          fleet.id === "suv" ? 4000 :
          fleet.id === "hatchback" ? 1800 :
          fleet.id === "sedan_prime" ? 2600 : 5000
        );
        const driverFee = Number(tierRate.rentalDriverAllowance) || Number(fleet.rentalDriverAllowance) || 1000;
        
        if (this.rentalMode === "with_driver" || this.withDriver) {
          finalPrice = baseRental + driverFee;
          priceNote = "Fixed (Chauffeur Allowance & GST incl.)";
          savingsText = "8 Hours / 80 KM • Verified Driver Included";
        } else {
          finalPrice = baseRental;
          priceNote = "Self-Drive Rental (Fixed Daily Price)";
          savingsText = "8 Hours / 80 KM • Doorstep Handover";
        }
        savings = Math.round(finalPrice * 0.25);
      } else {
        const perKm = Number(rates[fleet.id]?.perKm) || fleet.ratePerKm || 25;
        let baseFare = this.calculatedDistanceKm * perKm;
        const minFare = Number(rates[fleet.id]?.minFare) || (fleet.id === 'hatchback' ? 1698 : fleet.id === 'sedan' ? 2198 : fleet.id === 'sedan_prime' ? 2698 : fleet.id === 'innova_crysta' ? 4598 : 3398);
        baseFare = Math.max(baseFare, minFare);
        
        if (this.tripType === "roundtrip") {
          baseFare = (baseFare * 1.88); // 12% discount for roundtrip
        }

        finalPrice = Math.max(1000, Math.round(baseFare));
        savings = Math.round(baseFare * 0.95);
        savingsText = `Saved ~₹${savings.toLocaleString('en-IN')} vs Return Cab`;
      }

      const isSelected = this.selectedCabId === fleet.id;
      let carSvg = '';
      if (fleet.id === 'suv' || fleet.id === 'innova_crysta') {
        carSvg = `<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="var(--owc-primary)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-4c0-.9-.7-1.7-1.5-1.9L16 9.5 13 6H5c-.6 0-1.1.4-1.4.9L2.1 11c-.1.3-.1.7-.1 1v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2.5"/><circle cx="17" cy="17" r="2.5"/><path d="M5 11h14M10 6v5M14 6v5"/></svg>`;
      } else if (fleet.id === 'sedan' || fleet.id === 'sedan_prime') {
        carSvg = `<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="var(--owc-primary)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9L16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H6c-.6 0-1.1.4-1.4.9l-1.5 2.8C3.1 11 3 11.5 3 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2.5"/><circle cx="17" cy="17" r="2.5"/><path d="M5 11h14"/></svg>`;
      } else {
        carSvg = `<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="var(--owc-primary)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3.5c0-.9-.7-1.6-1.5-1.8L16 10l-2-3H6c-.6 0-1.1.4-1.4.9l-2 3.1C2.3 11.4 2 11.9 2 12.5v3.5c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2.5"/><circle cx="17" cy="17" r="2.5"/><path d="M5 11h13"/></svg>`;
      }

      return `
        <div class="cab-tier-card ${isSelected ? 'selected' : ''}" onclick="window.bookingManager.selectCabTier('${fleet.id}')">
          <span class="cab-ribbon-tag">${fleet.badge}</span>
          <div class="cab-card-top">
            <div class="cab-header-info">
              <h3>${fleet.category}</h3>
              <div class="cab-models-sub">${fleet.models}</div>
            </div>
            <div class="cab-icon-hero">
              ${carSvg}
            </div>
          </div>

          <div class="cab-specs-chips">
            <span class="cab-spec-chip">${fleet.seats} Seats</span>
            <span class="cab-spec-chip">${fleet.luggage}</span>
            <span class="cab-spec-chip">${fleet.ac}</span>
            <span class="cab-spec-chip"><svg width="11" height="11" viewBox="0 0 24 24" fill="#f59e0b" stroke="#f59e0b" style="margin-right:2px; vertical-align: -1px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>${fleet.rating}</span>
          </div>

          <p style="font-size: 12.5px; color: var(--owc-text-muted); line-height: 1.4; margin-bottom: 12px;">
            ${fleet.description}
          </p>

          <div class="cab-price-container">
            <div class="cab-price-row">
              <div class="cab-price-main">₹${finalPrice.toLocaleString('en-IN')}</div>
              <div class="cab-tax-note">${priceNote}</div>
            </div>
            <span class="cab-savings-pill">${savingsText}</span>
          </div>

          <button type="button" class="btn-select-cab" onclick="window.bookingManager.startCheckout('${fleet.id}', ${finalPrice})">
            ${isSelected ? 'Selected — Book Now' : 'Select ' + fleet.category}
          </button>
        </div>
      `;
    }).join("");
  }

  selectCabTier(cabId) {
    this.selectedCabId = cabId;
    this.renderFleetCards();
  }

  loadRoutePreset(fromId, toId) {
    const from = OTB_CITIES.find(c => c.id === fromId);
    const to = OTB_CITIES.find(c => c.id === toId);
    if (!from || !to) return;

    this.originCity = from;
    this.destCity = to;

    const pInput = document.getElementById("input-pickup");
    const dInput = document.getElementById("input-drop");
    if (pInput) pInput.value = `${from.name}${from.district && from.district !== from.name ? ', ' + from.district : ''} (${from.hindiName || ''}), ${from.state}`;
    if (dInput) dInput.value = `${to.name}${to.district && to.district !== to.name ? ', ' + to.district : ''} (${to.hindiName || ''}), ${to.state}`;

    window.closeAllModals();

    const phoneInput = document.getElementById("input-fare-phone");
    const rawPhone = (phoneInput?.value || this.userPhone || "").replace(/\D/g, "");
    const hasValidPhone = rawPhone.length === 10 && /^[6-9]\d{9}$/.test(rawPhone);

    if (hasValidPhone) {
      this.isFareUnlocked = true;
      const section = document.getElementById("cab-selection-section");
      const mapSection = document.getElementById("route-map-section");
      if (section) {
        section.classList.remove("fare-section-closed");
        section.classList.add("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.remove("fare-section-closed");
        mapSection.classList.add("fare-section-open");
      }
      this.calculateAndRenderFares();
      if (section) {
        setTimeout(() => {
          section.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 120);
      }
      window.showToast(`Selected route: ${from.name} → ${to.name}`, "success");
      this.transferLeadToHelpdesk(rawPhone, true, { source: `Route Selected: ${from.name} to ${to.name}` });
    } else {
      this.isFareUnlocked = false;
      const section = document.getElementById("cab-selection-section");
      const mapSection = document.getElementById("route-map-section");
      if (section) {
        section.classList.add("fare-section-closed");
        section.classList.remove("fare-section-open");
      }
      if (mapSection) {
        mapSection.classList.add("fare-section-closed");
        mapSection.classList.remove("fare-section-open");
      }
      if (phoneInput) {
        phoneInput.focus();
        const phoneGroup = document.getElementById("phone-check-group");
        if (phoneGroup) {
          phoneGroup.classList.add("shake-error");
          setTimeout(() => phoneGroup.classList.remove("shake-error"), 600);
        }
      }
      window.showToast(`Route set: ${from.name} → ${to.name}. Please enter your 10-digit mobile number to view fares.`, "warning");
      document.querySelector(".search-card-hero")?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
    this.updateCheckFareButtonState();
  }

  renderPopularRouteChips() {
    const container = document.getElementById("hero-quick-routes");
    if (!container) return;

    container.innerHTML = OTB_POPULAR_ROUTES.slice(0, 6).map(r => `
      <button type="button" class="quick-route-chip" onclick="window.bookingManager.loadRoutePreset('${r.fromId}', '${r.toId}')">
        ${r.from} → ${r.to} • ₹${r.baseFareHatchback}
      </button>
    `).join("");
  }

  renderFriendsHeroReviews() {
    const container = document.getElementById("fr-hero-feed");
    if (!container) return;

    const list = typeof getActiveReviews === "function" ? getActiveReviews() : (window.OTB_PASSENGER_REVIEWS || []);
    container.innerHTML = list.slice(0, 3).map(rev => {
      const quote = rev.comment ? (rev.comment.length > 82 ? rev.comment.substring(0, 79) + '...' : rev.comment) : 'Punctual driver, clean AC car and zero return fare.';
      return `
        <div class="fr-feed-item" onclick="window.openFriendsReviewModal()" title="Click to view all verified passenger reviews">
          <div class="fr-feed-top">
            <div class="fr-feed-user">
              <div class="fr-avatar-badge" style="background: ${rev.avatarBg || '#0084e8'}">${rev.initials || rev.name.charAt(0)}</div>
              <div class="fr-feed-user-meta">
                <div class="fr-feed-name">
                  <span class="fr-author-name">${rev.name}</span>
                  <span class="fr-verified-badge">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="vertical-align: -1px; margin-right: 2px;"><polyline points="20 6 9 17 4 12"/></svg>
                    Verified Trip
                  </span>
                </div>
                <div class="fr-feed-route-tag">${rev.route} &bull; ${rev.car}</div>
              </div>
            </div>
            <div class="fr-feed-rating">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="#f59e0b" stroke="#f59e0b" style="margin-right: 2px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span>${rev.rating}</span>
            </div>
          </div>
          <p class="fr-feed-quote">"${quote}"</p>
        </div>
      `;
    }).join("");
  }

  renderWhyChooseCards() {
    const container = document.getElementById("why-choose-grid");
    if (!container) return;

    container.innerHTML = OTB_WHY_CHOOSE_US.map(item => `
      <div class="why-feature-card">
        <div class="why-num-box">${item.num}</div>
        <div>
          <h3>${item.title}</h3>
          <p>${item.desc}</p>
        </div>
      </div>
    `).join("");
  }

  renderTestimonials() {
    const container = document.getElementById("testimonials-grid");
    if (!container) return;

    const list = typeof getActiveReviews === "function" ? getActiveReviews() : (window.OTB_PASSENGER_REVIEWS || []);
    container.innerHTML = list.slice(0, 3).map(t => `
      <div class="testimonial-card">
        <div class="quote-icon-decor">“</div>
        <div>
          <div class="test-stars-row" style="color: #f59e0b; font-weight: 800; font-size: 13.5px; margin-bottom: 8px; display: flex; align-items: center; gap: 4px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#f59e0b" stroke="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <span>${t.rating} / 5.0 Rating</span>
          </div>
          <p class="test-quote-text">"${t.comment}"</p>
        </div>
        <div class="test-author-block">
          <div class="test-author-name">${t.name}</div>
          <div class="test-author-route" style="color: var(--owc-primary); font-weight: 600; font-size: 12px; margin-top: 2px;">Verified Route: ${t.route}</div>
        </div>
      </div>
    `).join("");
  }

  renderMajorCities() {
    const container = document.getElementById("major-cities-grid");
    if (!container) return;

    const top8 = ["patna", "gaya", "muzaffarpur", "bhagalpur", "darbhanga", "nalanda", "rohtas", "purnia"];
    const filtered = OTB_CITIES.filter(c => top8.includes(c.id));

    container.innerHTML = filtered.map(c => `
      <div class="city-hub-card" onclick="window.bookingManager.loadRoutePreset('patna', '${c.id}')">
        <div class="city-hub-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        </div>
        <div class="city-hub-content">
          <div class="city-hub-title-row">
            <span class="city-hub-name">${c.name}</span>
            ${c.hindiName ? `<span class="city-hindi-tag">${c.hindiName}</span>` : ''}
          </div>
          <div class="city-hub-state">${c.division} Division • ${c.tag}</div>
        </div>
      </div>
    `).join("");
  }

  renderFAQs() {
    const container = document.getElementById("faq-accordion-container");
    if (!container) return;

    container.innerHTML = OTB_FAQS.map((faq, idx) => `
      <div class="faq-item ${idx === 0 ? 'active' : ''}">
        <button type="button" class="faq-question-btn" onclick="this.parentElement.classList.toggle('active')" aria-expanded="${idx === 0 ? 'true' : 'false'}">
          <span class="faq-question-text">${faq.q}</span>
          <span class="faq-chevron">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </span>
        </button>
        <div class="faq-answer-pane">
          ${faq.a}
        </div>
      </div>
    `).join("");
  }

  renderFooterRoutes() {
    const container = document.getElementById("footer-routes-list");
    if (!container) return;

    const routePageMap = {
      "patna-gaya": "patna-to-gaya-cab.html",
      "patna-muzaffarpur": "patna-to-muzaffarpur-cab.html",
      "patna-darbhanga": "patna-to-darbhanga-cab.html",
      "patna-bhagalpur": "patna-to-bhagalpur-cab.html"
    };

    container.innerHTML = OTB_POPULAR_ROUTES.map(r => {
      const pageUrl = routePageMap[r.id];
      const href = pageUrl || "javascript:void(0)";
      const clickHandler = pageUrl ? "" : `onclick="window.bookingManager.loadRoutePreset('${r.fromId}', '${r.toId}')"`;
      return `
        <a href="${href}" ${clickHandler} class="footer-route-pill" title="Book ${r.from} to ${r.to} One-Way Cab">
          <span class="frp-route">${r.from} ➔ ${r.to}</span>
          <span class="frp-price">from ₹${r.baseFareHatchback}</span>
        </a>
      `;
    }).join("");
  }

  /* ==========================================================================
     CHECKOUT, PASSENGER DETAILS & TICKET CONFIRMATION
     ========================================================================== */
  openCheckoutModal(cabId = "sedan", price = null) {
    if (!price) {
      const fleet = OTB_FLEET.find(f => f.id === cabId) || OTB_FLEET[1];
      price = Math.max(2198, Math.round((this.calculatedDistanceKm || 104) * (fleet.ratePerKm || 25)));
    }
    return this.startCheckout(cabId, price);
  }

  startCheckout(cabId, price) {
    this.selectedCabId = cabId;

    if (!this.originCity || !this.destCity) {
      window.showToast("Please enter or select your pickup and drop location", "info");
      const hero = document.getElementById("booking-hero");
      if (hero) hero.scrollIntoView({ behavior: "smooth" });
      const pInput = document.getElementById("input-pickup");
      const dInput = document.getElementById("input-drop");
      if (!this.originCity && pInput) {
        pInput.focus();
        const pDropdown = document.getElementById("pickup-dropdown");
        if (pDropdown) this.handleCitySearch("pickup", "", pDropdown, true);
      } else if (!this.destCity && dInput) {
        dInput.focus();
        const dDropdown = document.getElementById("drop-dropdown");
        if (dDropdown) this.handleCitySearch("drop", "", dDropdown, true);
      }
      return;
    }

    const fleet = OTB_FLEET.find(f => f.id === cabId) || OTB_FLEET[1];

    // Phone verification at time of booking: Require Firebase OTP verification
    const phoneInputHero = document.getElementById("input-fare-phone");
    const rawPhone = (phoneInputHero?.value || this.userPhone || localStorage.getItem("oneway_fare_phone") || window.currentUser?.phone || "").replace(/\D/g, "").slice(-10);

    if (rawPhone && rawPhone.length === 10 && /^[6-9]\d{9}$/.test(rawPhone)) {
      this.userPhone = rawPhone;
      this.passengerDetails.phone = `+91 ${rawPhone}`;
      this.transferLeadToHelpdesk(rawPhone, true, {
        selectedCab: cabId,
        cabPrice: price,
        source: `Cab Selected: ${fleet.category || cabId}`
      });
    }

    if (window.currentUser) {
      if (window.currentUser.name && (!this.passengerDetails.name || this.passengerDetails.name === "Passenger")) {
        this.passengerDetails.name = window.currentUser.name;
      }
      if (window.currentUser.phone && (!this.passengerDetails.phone || this.passengerDetails.phone === "+91")) {
        this.passengerDetails.phone = window.currentUser.phone;
      }
    } else if (rawPhone) {
      this.passengerDetails.phone = `+91 ${rawPhone}`;
    }

    const checkoutModal = document.getElementById("modal-checkout");
    const checkoutBody = document.getElementById("modal-checkout-body");

    if (!checkoutModal || !checkoutBody) return;

    this.currentCheckoutPrice = price;
    this.currentCheckoutFleet = fleet;
    this.appliedCouponCode = "";
    this.appliedCouponDiscount = 0;
    this.tempBookingId = "OTB-2026-" + Math.floor(1000 + Math.random() * 9000);

    const km = this.calculatedDistanceKm || 104;
    const isRental = (this.tripType === "rental" || this.tripType === "local");
    const baseKm = isRental ? 80 : (fleet.baseKm || 15);
    const extraKm = Math.max(0, km - baseKm);
    const perKm = (this.activeFleetRates?.[fleet.id]?.perKm) || fleet.ratePerKm || fleet.perKmRate || 25;
    const baseFareAmount = (fleet.baseFare !== undefined) ? fleet.baseFare : Math.round(baseKm * perKm);
    const distanceCharge = Math.round(extraKm * perKm);
    const toll = isRental ? 0 : Math.round((km / 70) * 55);
    const allowance = isRental ? (this.withDriver ? 1000 : 0) : ((this.tripType === "roundtrip" || km > 200) ? 350 : 0);
    const isAirport = Boolean(this.originCity?.name?.toLowerCase().includes("airport") || this.destCity?.name?.toLowerCase().includes("airport"));
    const parking = isAirport ? 100 : 0;
    const finalPayableInit = Math.max(0, price - 100);

    checkoutBody.innerHTML = `
      <div class="checkout-wrapper">

        <!-- Progress Stepper (Req 136) -->
        <div class="checkout-stepper">
          <div class="stepper-step active" id="stepper-step-1" onclick="window.bookingManager.goToCheckoutStep(1)">
            <span class="stepper-num">1</span>
            <span>Passenger Details</span>
          </div>
          <div class="stepper-line"></div>
          <div class="stepper-step" id="stepper-step-2" onclick="window.bookingManager.goToCheckoutStep(2)">
            <span class="stepper-num">2</span>
            <span>Summary &amp; Payment</span>
          </div>
        </div>

        <!-- Top Route Banner -->
        <div class="checkout-summary-strip">
          <div class="checkout-summary-top">
            <div class="checkout-route-badge">
              <span>${this.originCity.name}</span>
              <span style="color: #38bdf8;">➔</span>
              <span>${this.destCity.name}</span>
            </div>
            <span class="checkout-cab-tag">${fleet.category} (${fleet.models})</span>
          </div>

          <div class="checkout-meta-row">
            <span>${this.pickupDate} at ${this.pickupTime} • ${km} KM</span>
            <button type="button" class="checkout-breakdown-btn" id="checkout-breakdown-toggle-btn" onclick="window.bookingManager.toggleFareBreakdown()">
              <span>Fare Breakdown</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
          </div>

          <!-- Expandable Detailed Itemized Fare Breakdown -->
          <div class="checkout-breakdown-content" id="checkout-breakdown-box">
            <div class="checkout-breakdown-row">
              <span>Base Fare (First ${baseKm} KM):</span>
              <strong style="color: #ffffff;">₹${baseFareAmount.toLocaleString('en-IN')}</strong>
            </div>
            <div class="checkout-breakdown-row">
              <span>Distance Charge (${extraKm} KM @ ₹${perKm}/KM):</span>
              <strong style="color: #ffffff;">₹${distanceCharge.toLocaleString('en-IN')}</strong>
            </div>
            <div class="checkout-breakdown-row">
              <span>Highway Tolls &amp; Fastag:</span>
              <span style="color: #4ade80; font-weight: 700;">Included (₹${toll})</span>
            </div>
            <div class="checkout-breakdown-row">
              <span>Parking Charges:</span>
              <span style="color: #4ade80; font-weight: 700;">${parking > 0 ? `Included (₹${parking})` : "₹0 (Free)"}</span>
            </div>
            <div class="checkout-breakdown-row">
              <span>Driver Allowance:</span>
              <span style="color: #4ade80; font-weight: 700;">${allowance > 0 ? `Included (₹${allowance})` : "₹0 (Day Ride)"}</span>
            </div>
            <div class="checkout-breakdown-row">
              <span>Taxes &amp; 5% GST:</span>
              <span style="color: #4ade80; font-weight: 700;">Included</span>
            </div>
            <div class="checkout-breakdown-row" style="border-top: 1px dashed rgba(255,255,255,0.2); margin-top: 4px; padding-top: 4px; font-weight: 800; color: #ffffff;">
              <span>Total Calculated Cab Fare:</span>
              <span>₹${price.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <!-- ================= STEP 1: PASSENGER DETAILS ================= -->
        <div id="checkout-step-1" class="checkout-step-panel">
          <div class="checkout-section-title">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <span>Step 1: Enter Passenger Information</span>
          </div>

          <div class="checkout-form-grid">
            <div class="input-field-group">
              <span class="input-icon-clean">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </span>
              <div class="input-content">
                <label>PASSENGER FULL NAME *</label>
                <input type="text" id="chk-name" value="${this.passengerDetails.name || window.currentUser?.name || ''}" placeholder="Enter passenger name" autocomplete="name">
              </div>
            </div>

            <div class="input-field-group">
              <span class="input-icon-clean">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              </span>
              <div class="input-content">
                <label>10-DIGIT MOBILE NUMBER *</label>
                <input type="tel" id="chk-phone" value="${this.passengerDetails.phone || window.currentUser?.phone || ''}" placeholder="e.g. 8002141816" autocomplete="tel">
              </div>
            </div>
          </div>

          <!-- Exact Pickup Address -->
          <div class="input-field-group" style="margin-top: 8px;">
            <span class="input-icon-clean">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </span>
            <div class="input-content" style="position: relative;">
              <label>EXACT PICKUP DOORSTEP ADDRESS / LANDMARK</label>
              <input type="text" id="chk-pickup-addr" value="${this.passengerDetails.pickupAddress || ''}" placeholder="e.g. Near Patna Junction, Frazer Road" autocomplete="off">
              <div class="checkout-loc-dropdown" id="chk-pickup-dropdown" style="display: none;"></div>
            </div>
          </div>
          <div class="auto-type-chips-wrapper" id="pickup-auto-chips">
            <div class="auto-type-loading"><span>Loading popular pickup hubs...</span></div>
          </div>

          <!-- Exact Drop Address -->
          <div class="input-field-group" style="margin-top: 4px;">
            <span class="input-icon-clean">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
            </span>
            <div class="input-content" style="position: relative;">
              <label>EXACT DROP DESTINATION ADDRESS / HOTEL / VILLAGE</label>
              <input type="text" id="chk-drop-addr" value="${this.passengerDetails.dropAddress || ''}" placeholder="e.g. Bodh Gaya Temple Road, Hotel Lotus" autocomplete="off">
              <div class="checkout-loc-dropdown" id="chk-drop-dropdown" style="display: none;"></div>
            </div>
          </div>
          <div class="auto-type-chips-wrapper" id="drop-auto-chips">
            <div class="auto-type-loading"><span>Loading popular drop locations...</span></div>
          </div>

          <!-- Step 1 CTA Button -->
          <div style="margin-top: 14px;">
            <button type="button" class="check-fare-primary-btn" style="width: 100%; min-height: 48px; font-size: 15px; font-weight: 800;" onclick="window.bookingManager.goToCheckoutStep(2)">
              Review Booking Summary &amp; Pay →
            </button>
          </div>
        </div>

        <!-- ================= STEP 2: BOOKING SUMMARY & PAYMENT (Req 138, 140-143) ================= -->
        <div id="checkout-step-2" class="checkout-step-panel" style="display: none;">
          
          <div class="checkout-section-title">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <span>Step 2: Review Booking Summary &amp; Select Payment</span>
          </div>

          <!-- 12-Item Clean & Professional Booking Summary Card (Req 140 - 143) -->
          <div class="checkout-summary-card">
            <div class="summary-card-head">
              <span>PREVIEW BOOKING SUMMARY</span>
              <span id="sum-ref-badge" style="background: rgba(255,255,255,0.2); padding: 2px 8px; border-radius: 4px; font-family: monospace;">${this.tempBookingId}</span>
            </div>
            <div class="summary-table">
              
              <!-- 1. Booking Reference -->
              <div class="summary-row">
                <span class="summary-row-label">Booking ID</span>
                <span class="summary-row-val"><strong style="color: var(--owc-primary); font-family: monospace;" id="sum-booking-id">${this.tempBookingId}</strong></span>
              </div>

              <!-- 2. Pickup Location -->
              <div class="summary-row">
                <span class="summary-row-label">Pickup</span>
                <span class="summary-row-val">
                  <span id="sum-pickup-val">${this.originCity.name}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('pickup')">Edit</button>
                </span>
              </div>

              <!-- 3. Drop Location -->
              <div class="summary-row">
                <span class="summary-row-label">Drop</span>
                <span class="summary-row-val">
                  <span id="sum-drop-val">${this.destCity.name}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('drop')">Edit</button>
                </span>
              </div>

              <!-- 4. Travel Date -->
              <div class="summary-row">
                <span class="summary-row-label">Travel Date</span>
                <span class="summary-row-val">
                  <span id="sum-date-val">${this.pickupDate}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('date')">Edit</button>
                </span>
              </div>

              <!-- 5. Pickup Time -->
              <div class="summary-row">
                <span class="summary-row-label">Pickup Time</span>
                <span class="summary-row-val">
                  <span id="sum-time-val">${this.pickupTime}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('time')">Edit</button>
                </span>
              </div>

              <!-- 6. Passenger Name -->
              <div class="summary-row">
                <span class="summary-row-label">Passenger</span>
                <span class="summary-row-val">
                  <span id="sum-name-val">${this.passengerDetails.name || 'Passenger'}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('name')">Edit</button>
                </span>
              </div>

              <!-- 7. Passenger Phone -->
              <div class="summary-row">
                <span class="summary-row-label">Phone</span>
                <span class="summary-row-val">
                  <span id="sum-phone-val">${this.passengerDetails.phone || ''}</span>
                  <button type="button" class="btn-edit-field" onclick="window.bookingManager.editField('phone')">Edit</button>
                </span>
              </div>

              <!-- 8. Cab Fleet -->
              <div class="summary-row">
                <span class="summary-row-label">Cab Model</span>
                <span class="summary-row-val">
                  <span>${fleet.category} (${fleet.models})</span>
                </span>
              </div>

              <!-- 9. Calculated Fare -->
              <div class="summary-row">
                <span class="summary-row-label">Total Fare</span>
                <span class="summary-row-val">
                  <span>₹${price.toLocaleString('en-IN')} (All-inclusive)</span>
                </span>
              </div>

              <!-- 10. Wallet Used -->
              <div class="summary-row">
                <span class="summary-row-label">Wallet Used</span>
                <span class="summary-row-val">
                  <span style="color: #059669; font-weight: 800;" id="sum-wallet-used">-₹100</span>
                </span>
              </div>

              <!-- 10b. Coupon Promo Discount -->
              <div class="summary-row" id="sum-coupon-row" style="display: none; background: rgba(16, 185, 129, 0.06);">
                <span class="summary-row-label" style="color: #059669; font-weight: 700;">Coupon Promo (<span id="sum-coupon-code"></span>)</span>
                <span class="summary-row-val">
                  <span style="color: #059669; font-weight: 800;" id="sum-coupon-discount">-₹0</span>
                </span>
              </div>

              <!-- 11. Remaining Payment -->
              <div class="summary-row" style="background: rgba(0, 154, 244, 0.05);">
                <span class="summary-row-label" style="color: var(--owc-primary); font-weight: 800;">Remaining Payment</span>
                <span class="summary-row-val">
                  <strong style="color: var(--owc-primary); font-size: 15px;" id="sum-final-payable">₹${finalPayableInit.toLocaleString('en-IN')}</strong>
                </span>
              </div>

              <!-- 12. Payment Method -->
              <div class="summary-row">
                <span class="summary-row-label">Payment Mode</span>
                <span class="summary-row-val">
                  <span id="sum-method-val" style="color: #0070f3; font-weight: 800;">Pay ₹299 Token Advance (Instant Cab Lock)</span>
                </span>
              </div>

            </div>
          </div>

          <!-- Wallet Savings Box -->
          <label class="checkout-wallet-box" style="margin-top: 10px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <input type="checkbox" id="chk-use-wallet" checked onchange="window.bookingManager.updateCheckoutPayable(${price})" style="accent-color: #059669; width: 19px; height: 19px; cursor: pointer;">
              <div>
                <strong style="color: #0f172a; font-size: 13.5px; display: block;">Apply Wallet Bonus (-₹100)</strong>
                <span style="font-size: 11.5px; color: #15803d; font-weight: 600;">
                  ${window.currentUser ? `Available Wallet: ₹${window.currentUser.walletBalance || 100}` : '₹100 Welcome Discount Applied'}
                </span>
              </div>
            </div>
            <span style="color: #15803d; font-weight: 800; font-size: 15px;" id="chk-wallet-deduct-label">-₹100</span>
          </label>

          <!-- Promo Coupon Box -->
          <div class="checkout-coupon-box" style="margin-top: 10px; background: rgba(2, 132, 199, 0.04); border: 1px dashed #38bdf8; border-radius: 12px; padding: 12px 14px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <span style="font-size: 11.5px; font-weight: 800; color: #0284c7; text-transform: uppercase; letter-spacing: 0.5px;">Apply Promo Coupon</span>
              <span style="font-size: 10.5px; color: var(--owc-text-muted);">Try: <strong style="color: #0284c7;">FIRST100</strong>, <strong style="color: #0284c7;">BIHAR50</strong>, <strong style="color: #0284c7;">FESTIVE10</strong></span>
            </div>
            <div style="display: flex; gap: 8px;">
              <input type="text" id="chk-coupon-input" placeholder="ENTER COUPON CODE" style="flex: 1; text-transform: uppercase; font-weight: 800; padding: 8px 12px; border: 1px solid var(--owc-border); border-radius: 8px; font-size: 13px; background: var(--owc-card-bg); color: var(--owc-text);">
              <button type="button" id="chk-coupon-apply-btn" style="padding: 8px 16px; font-size: 12px; font-weight: 800; border-radius: 8px; background: #0284c7; color: white; border: none; cursor: pointer;" onclick="window.bookingManager.handleApplyCoupon(${price})">
                Apply
              </button>
            </div>
            <div id="chk-coupon-msg" style="font-size: 11.5px; margin-top: 6px; display: none;"></div>
          </div>

          <!-- Payment Options Header -->
          <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 14px; margin-bottom: 8px;">
            <div style="font-size: 13px; font-weight: 800; color: var(--owc-text); text-transform: uppercase; letter-spacing: 0.4px;">
              Select Payment Mode
            </div>
            <div style="display: flex; align-items: center; gap: 4px; font-size: 11px; color: #059669; font-weight: 700;">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              <span>100% Safe &amp; Encrypted</span>
            </div>
          </div>

          <!-- Payment Options List -->
          <div class="checkout-methods-list" style="display: flex; flex-direction: column; gap: 8px;">
            
            <!-- Method 1: Direct PhonePe / BHIM UPI QR (Default & Recommended) -->
            <label class="checkout-method-item active" id="pay-card-upi" style="border: 1.5px solid #5f259f; background: rgba(95, 37, 159, 0.04); border-radius: 12px; padding: 13px 15px; cursor: pointer; display: block; transition: all 0.2s ease;">
              <div class="checkout-method-header" style="display: flex; align-items: flex-start; gap: 11px;">
                <input type="radio" name="pay-method" value="Direct UPI / QR Advance (₹299)" checked onchange="window.bookingManager.handlePaymentMethodChange(this.value)" style="margin-top: 3px; accent-color: #5f259f; width: 18px; height: 18px; cursor: pointer;">
                <div style="flex: 1;">
                  <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px;">
                    <strong style="color: #5f259f; font-size: 14px; font-weight: 800;">
                      Pay ₹299 Token Advance via PhonePe / UPI QR
                    </strong>
                    <div style="display: flex; gap: 5px;">
                      <span style="font-size: 9.5px; background: #5f259f; color: #fff; padding: 2px 7px; border-radius: 4px; font-weight: 800; letter-spacing: 0.3px;">RECOMMENDED</span>
                      <span style="font-size: 9.5px; background: rgba(16, 185, 129, 0.15); color: #059669; border: 1px solid #10b981; padding: 1px 6px; border-radius: 4px; font-weight: 800;">INSTANT CAB LOCK</span>
                    </div>
                  </div>
                  <div style="font-size: 11.5px; color: var(--owc-text-muted); margin-top: 4px; line-height: 1.45;">
                    Lock your confirmed cab &amp; chauffeur instantly! Scan verified merchant QR code or tap to pay ₹299 token advance via <strong>PhonePe, Google Pay, Paytm or BHIM</strong>. Remaining fare payable directly to driver at destination.
                  </div>
                  <div style="display: flex; align-items: center; gap: 6px; margin-top: 6px; font-size: 10.5px; color: #475569;">
                    <span style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-weight: 700;">PhonePe</span>
                    <span style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-weight: 700;">GPay</span>
                    <span style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-weight: 700;">Paytm</span>
                    <span style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-weight: 700;">BHIM UPI</span>
                    <span style="color: #059669; font-weight: 700; margin-left: auto;">✓ 0% Gateway Fees</span>
                  </div>
                </div>
              </div>

              <div class="checkout-qr-wrapper" id="checkout-qr-box" style="display: block; margin-top: 12px; background: #faf5ff; border: 1.5px solid #d946ef; border-radius: 12px; padding: 14px; text-align: center;">
                <div style="font-size: 11px; font-weight: 800; color: #5f259f; letter-spacing: 0.6px; margin-bottom: 8px;">INSTANT 0% FEE • PHONEPE • GPAY • PAYTM • BHIM</div>
                
                <!-- Dynamic Amount Embedded QR Code with offline fallback -->
                <img id="chk-qr-img" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=6&data=${encodeURIComponent(`upi://pay?pa=${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}&pn=${encodeURIComponent(this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey')}&am=299&cu=INR&tn=OneWayTaxiBihar%20Advance`)}" onerror="this.onerror=null; this.src='images/phonepe-qr.png';" alt="Dynamic UPI Payment QR Code" class="checkout-qr-img" style="width: 150px; height: 150px; border-radius: 10px; border: 1.5px solid #d946ef; margin: 0 auto; display: block; object-fit: contain; background: white; padding: 4px; box-shadow: 0 4px 12px rgba(95,37,159,0.1);">
                
                <div id="chk-payee-name" style="margin-top: 8px; font-size: 13.5px; font-weight: 800; color: #0f172a;">${this.dynamicPaymentConfig?.payeeName || 'HIMANSHU KUMAR DUBEY'}</div>
                
                <!-- Verified UPI ID Pill with 1-click Copy -->
                <div class="checkout-upi-pill" style="display: inline-flex; align-items: center; gap: 8px; background: white; border: 1px solid #cbd5e1; padding: 4px 12px; border-radius: 20px; margin-top: 6px;">
                  <span id="chk-upi-id-label" style="font-weight: 700; color: #334155; font-size: 12.5px; font-family: monospace;">${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}</span>
                  <button type="button" class="checkout-btn-copy" onclick="window.copyUpiId(document.getElementById('chk-upi-id-label')?.textContent?.trim() || '8002141816@ybl', this)" style="border: none; background: #e0e7ff; color: #3730a3; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; cursor: pointer;">Copy UPI ID</button>
                </div>

                <!-- 1-Tap Mobile Launch Buttons for PhonePe, GPay, Paytm, BHIM -->
                <div style="margin-top: 12px;">
                  <div style="font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 6px;">Tap to pay directly in your installed app:</div>
                  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 8px; max-width: 380px; margin: 0 auto;">
                    <a href="phonepe://pay?pa=${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}&pn=${encodeURIComponent(this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey')}&am=299&cu=INR&tn=OneWayTaxiBihar%20Advance" id="chk-upi-phonepe-link" style="display: flex; align-items: center; justify-content: center; gap: 5px; background: #5f259f; color: white; text-decoration: none; padding: 8px 6px; border-radius: 8px; font-size: 11.5px; font-weight: 800; box-shadow: 0 2px 6px rgba(95,37,159,0.25);">
                      🟣 PhonePe
                    </a>
                    <a href="gpay://upi/pay?pa=${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}&pn=${encodeURIComponent(this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey')}&am=299&cu=INR&tn=OneWayTaxiBihar%20Advance" id="chk-upi-gpay-link" style="display: flex; align-items: center; justify-content: center; gap: 5px; background: #1a73e8; color: white; text-decoration: none; padding: 8px 6px; border-radius: 8px; font-size: 11.5px; font-weight: 800; box-shadow: 0 2px 6px rgba(26,115,232,0.25);">
                      🟢 GPay
                    </a>
                    <a href="paytmmp://pay?pa=${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}&pn=${encodeURIComponent(this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey')}&am=299&cu=INR&tn=OneWayTaxiBihar%20Advance" id="chk-upi-paytm-link" style="display: flex; align-items: center; justify-content: center; gap: 5px; background: #00b9f5; color: white; text-decoration: none; padding: 8px 6px; border-radius: 8px; font-size: 11.5px; font-weight: 800; box-shadow: 0 2px 6px rgba(0,185,245,0.25);">
                      🔵 Paytm
                    </a>
                    <a href="upi://pay?pa=${this.dynamicPaymentConfig?.upiId || '8002141816@ybl'}&pn=${encodeURIComponent(this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey')}&am=299&cu=INR&tn=OneWayTaxiBihar%20Advance" id="chk-upi-intent-link" style="display: flex; align-items: center; justify-content: center; gap: 5px; background: #059669; color: white; text-decoration: none; padding: 8px 6px; border-radius: 8px; font-size: 11.5px; font-weight: 800; box-shadow: 0 2px 6px rgba(5,150,105,0.25);">
                      🟠 Any UPI
                    </a>
                  </div>
                </div>

                <!-- Direct Bank Account Transfer (IMPS / NEFT / RTGS) -->
                <div id="chk-bank-transfer-box" style="margin-top: 14px; background: #ffffff; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 12px 14px; text-align: left; box-shadow: 0 2px 6px rgba(0,0,0,0.03);">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; border-bottom: 1px solid #f1f5f9; padding-bottom: 6px;">
                    <div style="display: flex; align-items: center; gap: 6px;">
                      <span style="font-size: 14px;">🏦</span>
                      <strong style="font-size: 12px; color: #1e293b; letter-spacing: 0.3px;">DIRECT BANK ACCOUNT TRANSFER (IMPS / NEFT)</strong>
                    </div>
                    <span style="font-size: 9.5px; background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; padding: 1px 6px; border-radius: 4px; font-weight: 800;">VERIFIED A/C</span>
                  </div>
                  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 8px; font-size: 11.5px; color: #334155;">
                    <div style="background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                      <span style="font-size: 9.5px; color: #64748b; font-weight: 700; display: block; text-transform: uppercase;">Bank Name</span>
                      <strong id="chk-bank-name" style="color: #0f172a; font-size: 12px;">${this.dynamicPaymentConfig?.bankName || 'State Bank of India'}</strong>
                    </div>
                    <div style="background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                      <span style="font-size: 9.5px; color: #64748b; font-weight: 700; display: block; text-transform: uppercase;">Account Holder</span>
                      <strong id="chk-account-holder" style="color: #0f172a; font-size: 12px;">${this.dynamicPaymentConfig?.accountHolderName || this.dynamicPaymentConfig?.payeeName || 'HIMANSHU KUMAR DUBEY'}</strong>
                    </div>
                  </div>
                  <div style="display: grid; grid-template-columns: 1fr; gap: 6px; margin-top: 6px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                      <div>
                        <span style="font-size: 9.5px; color: #64748b; font-weight: 700; display: block; text-transform: uppercase;">Account Number</span>
                        <strong id="chk-account-number" style="font-family: monospace; font-size: 13.5px; color: #0f172a; letter-spacing: 0.5px;">${this.dynamicPaymentConfig?.accountNumber || 'Pending Configuration'}</strong>
                      </div>
                      <button type="button" class="btn-copy-account" onclick="window.copyToClipboard(document.getElementById('chk-account-number')?.textContent?.trim(), this, 'Account No')" style="border: 1px solid #cbd5e1; background: white; color: #0f172a; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s;">
                        Copy A/C
                      </button>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                      <div>
                        <span style="font-size: 9.5px; color: #64748b; font-weight: 700; display: block; text-transform: uppercase;">IFSC Code</span>
                        <strong id="chk-ifsc-code" style="font-family: monospace; font-size: 13.5px; color: #059669; letter-spacing: 0.5px;">${this.dynamicPaymentConfig?.ifscCode || 'SBIN0000001'}</strong>
                      </div>
                      <button type="button" class="btn-copy-ifsc" onclick="window.copyToClipboard(document.getElementById('chk-ifsc-code')?.textContent?.trim(), this, 'IFSC Code')" style="border: 1px solid #cbd5e1; background: white; color: #059669; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s;">
                        Copy IFSC
                      </button>
                    </div>
                  </div>
                  <div style="margin-top: 6px; font-size: 10.5px; color: #64748b; display: flex; align-items: center; gap: 4px;">
                    <span>Branch: <strong id="chk-bank-branch">${this.dynamicPaymentConfig?.branchName || 'Patna Main Branch'}</strong></span>
                    <span style="margin-left: auto;">IMPS / NEFT / RTGS Instant Credit</span>
                  </div>
                </div>

                <div style="margin-top: 12px; text-align: left; background: white; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;">
                  <label style="font-size: 11px; font-weight: 800; color: #334155; display: block; margin-bottom: 4px; text-transform: uppercase;">ENTER UPI / BANK TRANSACTION UTR NUMBER (AFTER PAYMENT):</label>
                  <input type="text" id="chk-upi-utr" placeholder="Enter 12-digit UPI UTR or Bank Ref number (e.g. 4235XXXXXXXX)" style="width: 100%; box-sizing: border-box; padding: 8px 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 12.5px; font-family: monospace;">
                </div>
              </div>
            </label>

            <!-- Method 2: Cash on Ride (Zero Advance) -->
            <label class="checkout-method-item" id="pay-card-cash" style="border: 1px solid var(--owc-border); background: var(--owc-card-bg); border-radius: 12px; padding: 13px 15px; cursor: pointer; display: block; transition: all 0.2s ease;">
              <div class="checkout-method-header" style="display: flex; align-items: flex-start; gap: 11px;">
                <input type="radio" name="pay-method" value="Cash on Ride (Zero Advance)" onchange="window.bookingManager.handlePaymentMethodChange(this.value)" style="margin-top: 3px; accent-color: #059669; width: 18px; height: 18px; cursor: pointer;">
                <div style="flex: 1;">
                  <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px;">
                    <strong style="color: var(--owc-text); font-size: 14px; font-weight: 800;">
                      100% Cash on Ride (Zero Advance)
                    </strong>
                    <span style="font-size: 9.5px; background: #059669; color: #fff; padding: 2px 7px; border-radius: 4px; font-weight: 800; letter-spacing: 0.3px;">ZERO ADVANCE</span>
                  </div>
                  <div style="font-size: 11.5px; color: var(--owc-text-muted); margin-top: 4px; line-height: 1.45;">
                    ₹0 payable now! Pay entire trip fare directly to your assigned chauffeur via Cash or Driver UPI upon reaching your destination safely.
                  </div>
                </div>
              </div>
            </label>

            <!-- Method 3: Credit/Debit Cards & NetBanking (Razorpay Online Gateway) -->
            <label class="checkout-method-item" id="pay-card-razorpay" style="border: 1px solid var(--owc-border); background: var(--owc-card-bg); border-radius: 12px; padding: 13px 15px; cursor: pointer; display: block; transition: all 0.2s ease;">
              <div class="checkout-method-header" style="display: flex; align-items: flex-start; gap: 11px;">
                <input type="radio" name="pay-method" value="Razorpay Online Advance (₹299)" onchange="window.bookingManager.handlePaymentMethodChange(this.value)" style="margin-top: 3px; accent-color: #0070f3; width: 18px; height: 18px; cursor: pointer;">
                <div style="flex: 1;">
                  <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px;">
                    <strong style="color: var(--owc-text); font-size: 14px; font-weight: 800;">
                      Credit / Debit Cards &amp; NetBanking (Razorpay)
                    </strong>
                    <span id="rzp-status-pill" style="font-size: 9.5px; background: #64748b; color: #fff; padding: 2px 7px; border-radius: 4px; font-weight: 800; letter-spacing: 0.3px;">${this.dynamicPaymentConfig?.razorpayConfigured ? 'GATEWAY ACTIVE' : 'CARDS & NETBANKING'}</span>
                  </div>
                  <div style="font-size: 11.5px; color: var(--owc-text-muted); margin-top: 4px; line-height: 1.45;">
                    ${this.dynamicPaymentConfig?.razorpayConfigured 
                      ? 'Pay ₹299 online using Visa, Mastercard, RuPay, or Corporate NetBanking.'
                      : 'Card & NetBanking gateway integration. Use Direct PhonePe / UPI QR above for instant confirmed dispatch.'}
                  </div>
                </div>
              </div>
            </label>

            <!-- Method 4: 100% Full Pre-payment Online -->
            <label class="checkout-method-item" id="pay-card-full" style="border: 1px solid var(--owc-border); background: var(--owc-card-bg); border-radius: 12px; padding: 13px 15px; cursor: pointer; display: block; transition: all 0.2s ease;">
              <div class="checkout-method-header" style="display: flex; align-items: flex-start; gap: 11px;">
                <input type="radio" name="pay-method" value="Full Online Payment" onchange="window.bookingManager.handlePaymentMethodChange(this.value)" style="margin-top: 3px; accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">
                <div style="flex: 1;">
                  <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px;">
                    <strong style="color: var(--owc-text); font-size: 14px; font-weight: 800;">
                      100% Full Pre-payment Online (Cashless Ride)
                    </strong>
                    <span style="font-size: 9.5px; background: #0284c7; color: #fff; padding: 2px 7px; border-radius: 4px; font-weight: 800; letter-spacing: 0.3px;">CASHLESS</span>
                  </div>
                  <div style="font-size: 11.5px; color: var(--owc-text-muted); margin-top: 4px; line-height: 1.45;">
                    Pay full ride amount online now. Enjoy complete hassle-free travel with zero driver cash payments. Instant digital GST receipt provided.
                  </div>
                </div>
              </div>
            </label>

          </div>

          <!-- Trust & Service Guarantee Badges (Uber / MakeMyTrip style) -->
          <div style="margin-top: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 12px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 11.5px; color: #334155;">
            <div style="display: flex; align-items: center; gap: 6px;">
              <span style="color: #059669; font-weight: 800; font-size: 13px;">✓</span>
              <span><strong>Verified Chauffeurs</strong> &amp; clean AC cabs</span>
            </div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <span style="color: #0284c7; font-weight: 800; font-size: 13px;">✓</span>
              <span><strong>5-Min Dispatch</strong> call confirmation</span>
            </div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <span style="color: #059669; font-weight: 800; font-size: 13px;">✓</span>
              <span><strong>Zero Surge Pricing</strong> (Fixed Fare)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <span style="color: #0284c7; font-weight: 800; font-size: 13px;">✓</span>
              <span><strong>256-Bit SSL</strong> RBI Safe Checkout</span>
            </div>
          </div>

          <!-- Sticky Action Bar in Step 2 -->
          <div class="checkout-action-bar" style="margin-top: 14px; background: var(--owc-card-bg); border-top: 1px solid var(--owc-border); padding: 12px 0 0 0; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
            <button type="button" class="btn-nav-outline" style="padding: 10px 14px; font-size: 12.5px; font-weight: 700;" onclick="window.bookingManager.goToCheckoutStep(1)">
              ← Edit Details
            </button>

            <div style="text-align: right; min-width: 110px;">
              <div style="font-size: 9.5px; font-weight: 800; color: var(--owc-text-muted); text-transform: uppercase; letter-spacing: 0.4px;" id="chk-payable-title-label">TOKEN ADVANCE NOW</div>
              <div style="font-size: 20px; font-weight: 900; color: var(--owc-primary);" id="chk-total-payable">₹299</div>
              <div style="font-size: 10px; color: var(--owc-text-muted);" id="chk-payable-sublabel">Balance due to driver: ₹${Math.max(0, finalPayableInit - 299).toLocaleString('en-IN')}</div>
            </div>

            <button type="button" class="check-fare-primary-btn" id="chk-confirm-cta-btn" style="flex: 1; max-width: 240px; margin: 0; min-height: 48px; font-size: 13.5px; font-weight: 800;" onclick="window.bookingManager.confirmBooking(${price})">
              Confirm Booking (₹299 Advance) →
            </button>
          </div>

        </div>

      </div>
    `;

    checkoutModal.classList.add("open");
    document.body.classList.add("modal-open");
    history.pushState({ modal: "modal-checkout", step: "checkout" }, "", "#checkout");
    this.saveState();
    this.setupCheckoutLocationAutocomplete();
    this.setupCheckoutFormPersistence();
    this.syncPaymentConfig();
  }

  goToCheckoutStep(step) {
    const step1 = document.getElementById("checkout-step-1");
    const step2 = document.getElementById("checkout-step-2");
    const pill1 = document.getElementById("stepper-step-1");
    const pill2 = document.getElementById("stepper-step-2");

    if (step === 2) {
      // Validate Step 1 Inputs
      const nameInput = document.getElementById("chk-name");
      const phoneInput = document.getElementById("chk-phone");
      const name = nameInput?.value.trim() || "";
      const phone = (phoneInput?.value || "").replace(/\D/g, "").slice(-10);

      if (!name || name.length < 2) {
        window.showToast("Please enter passenger full name", "warning");
        nameInput?.focus();
        return;
      }
      if (!phone || phone.length !== 10 || !/^[6-9]\d{9}$/.test(phone)) {
        window.showToast("Please enter a valid 10-digit Indian mobile number", "warning");
        phoneInput?.focus();
        return;
      }

      // Check if this specific phone number is OTP verified
      const isVerified = sessionStorage.getItem(`otb_verified_${phone}`) === "true" ||
        (window.currentUser && window.currentUser.isPhoneVerified && window.currentUser.phone?.includes(phone));

      if (!isVerified && window.firebaseOtpService) {
        window.firebaseOtpService.requestVerification(phone, name, (verifyResult) => {
          this.userPhone = phone;
          this.passengerDetails.name = name;
          this.passengerDetails.phone = `+91 ${phone}`;
          this.goToCheckoutStep(2);
        });
        return;
      }

      this.saveState();

      this.userPhone = phone;
      this.passengerDetails.name = name;
      this.passengerDetails.phone = `+91 ${phone}`;

      // Update Summary Values (Req 140)
      const pickupAddr = document.getElementById("chk-pickup-addr")?.value.trim();
      const dropAddr = document.getElementById("chk-drop-addr")?.value.trim();
      if (pickupAddr) this.passengerDetails.pickupAddress = pickupAddr;
      if (dropAddr) this.passengerDetails.dropAddress = dropAddr;

      // Sync lead immediately to Admin Desk
      this.transferLeadToHelpdesk(phone, true, {
        passengerName: name,
        selectedCab: this.selectedCabId,
        source: "Checkout Step 1 Form"
      });

      const pVal = document.getElementById("sum-pickup-val");
      const dVal = document.getElementById("sum-drop-val");
      const nVal = document.getElementById("sum-name-val");
      const phVal = document.getElementById("sum-phone-val");

      if (pVal) pVal.textContent = `${this.originCity.name}${pickupAddr ? ' (' + pickupAddr + ')' : ''}`;
      if (dVal) dVal.textContent = `${this.destCity.name}${dropAddr ? ' (' + dropAddr + ')' : ''}`;
      if (nVal) nVal.textContent = name;
      if (phVal) phVal.textContent = `+91 ${phone}`;

      if (step1) step1.style.display = "none";
      if (step2) step2.style.display = "block";

      if (pill1) {
        pill1.classList.remove("active");
        pill1.classList.add("completed");
        const numEl = pill1.querySelector(".stepper-num");
        if (numEl) numEl.textContent = "✓";
      }
      if (pill2) {
        pill2.classList.add("active");
      }
    } else {
      if (step1) step1.style.display = "block";
      if (step2) step2.style.display = "none";

      if (pill1) {
        pill1.classList.add("active");
        pill1.classList.remove("completed");
        const numEl = pill1.querySelector(".stepper-num");
        if (numEl) numEl.textContent = "1";
      }
      if (pill2) {
        pill2.classList.remove("active");
      }
    }

    const modalBody = document.getElementById("modal-checkout-body");
    if (modalBody) modalBody.scrollTop = 0;
  }

  editField(field) {
    if (field === "name") {
      this.goToCheckoutStep(1);
      setTimeout(() => document.getElementById("chk-name")?.focus(), 100);
    } else if (field === "phone") {
      this.goToCheckoutStep(1);
      setTimeout(() => document.getElementById("chk-phone")?.focus(), 100);
    } else if (field === "pickup") {
      this.goToCheckoutStep(1);
      setTimeout(() => document.getElementById("chk-pickup-addr")?.focus(), 100);
    } else if (field === "drop") {
      this.goToCheckoutStep(1);
      setTimeout(() => document.getElementById("chk-drop-addr")?.focus(), 100);
    } else if (field === "date" || field === "time") {
      window.closeAllModals(false);
      const hero = document.getElementById("booking-hero");
      if (hero) hero.scrollIntoView({ behavior: "smooth", block: "start" });
      setTimeout(() => {
        if (field === "date") window.ExecDateTimePicker?.openCalendar();
        else window.ExecDateTimePicker?.openClock();
      }, 300);
    }
  }

  setupCheckoutFormPersistence() {
    const fields = ["chk-name", "chk-phone", "chk-email", "chk-pickup-addr", "chk-drop-addr"];
    fields.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", () => this.saveState());
      }
    });

    const phoneEl = document.getElementById("chk-phone");
    const nameEl = document.getElementById("chk-name");
    if (phoneEl) {
      phoneEl.addEventListener("blur", () => {
        const p = phoneEl.value.replace(/\D/g, "").slice(-10);
        if (p.length === 10 && /^[6-9]\d{9}$/.test(p)) {
          this.userPhone = p;
          this.passengerDetails.phone = `+91 ${p}`;
          this.passengerDetails.name = nameEl ? nameEl.value.trim() : "";
          this.transferLeadToHelpdesk(p, true, {
            passengerName: this.passengerDetails.name || "Checkout Visitor",
            selectedCab: this.selectedCabId,
            source: "Checkout Modal Input"
          });
        }
      });
    }
  }

  toggleFareBreakdown() {
    const el = document.getElementById("checkout-breakdown-box");
    const btn = document.getElementById("checkout-breakdown-toggle-btn");
    if (!el) return;
    if (el.classList.contains("show")) {
      el.classList.remove("show");
      if (btn) btn.innerHTML = `<span>Fare Breakdown</span><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>`;
    } else {
      el.classList.add("show");
      if (btn) btn.innerHTML = `<span>Hide Breakdown</span><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="18 15 12 9 6 15"/></svg>`;
    }
  }

  handlePaymentMethodChange(method) {
    const qrBox = document.getElementById("checkout-qr-box");
    const cardRzp = document.getElementById("pay-card-razorpay");
    const cardUpi = document.getElementById("pay-card-upi");
    const cardCash = document.getElementById("pay-card-cash");
    const cardFull = document.getElementById("pay-card-full");

    const isCash = method.includes("Cash") || method.includes("Zero Advance") || method.includes("Driver");
    const isFull = !isCash && (method.includes("Full") || method.includes("100%"));
    const isUpi = !isCash && (method.includes("QR") || method.includes("PhonePe") || method.includes("Direct") || (method.includes("UPI") && !isCash));
    const isRzp = !isCash && !isUpi && (method.includes("Razorpay") || method.includes("Card") || method.includes("NetBanking"));

    if (cardRzp) {
      cardRzp.classList.toggle("active", isRzp);
      cardRzp.style.borderColor = isRzp ? "#0070f3" : "var(--owc-border)";
      cardRzp.style.background = isRzp ? "rgba(0, 112, 243, 0.04)" : "var(--owc-card-bg)";
    }
    if (cardUpi) {
      cardUpi.classList.toggle("active", isUpi);
      cardUpi.style.borderColor = isUpi ? "#5f259f" : "var(--owc-border)";
      cardUpi.style.background = isUpi ? "rgba(95, 37, 159, 0.04)" : "var(--owc-card-bg)";
    }
    if (cardCash) {
      cardCash.classList.toggle("active", isCash);
      cardCash.style.borderColor = isCash ? "#059669" : "var(--owc-border)";
      cardCash.style.background = isCash ? "rgba(5, 150, 105, 0.04)" : "var(--owc-card-bg)";
    }
    if (cardFull) {
      cardFull.classList.toggle("active", isFull);
      cardFull.style.borderColor = isFull ? "#0284c7" : "var(--owc-border)";
      cardFull.style.background = isFull ? "rgba(2, 132, 199, 0.04)" : "var(--owc-card-bg)";
    }

    if (qrBox) {
      qrBox.style.display = isUpi ? "block" : "none";
    }

    const sumMethodVal = document.getElementById("sum-method-val");
    if (sumMethodVal) {
      if (isCash) {
        sumMethodVal.textContent = "100% Cash on Ride (Zero Advance)";
        sumMethodVal.style.color = "#059669";
      } else if (isFull) {
        sumMethodVal.textContent = "100% Full Pre-payment Online";
        sumMethodVal.style.color = "#0284c7";
      } else if (isUpi) {
        sumMethodVal.textContent = "Direct PhonePe / BHIM UPI QR Code (₹299)";
        sumMethodVal.style.color = "#5f259f";
      } else {
        sumMethodVal.textContent = "Credit / Debit Cards & NetBanking (Razorpay)";
        sumMethodVal.style.color = "#0070f3";
      }
    }

    this.updateCheckoutPayable(this.currentCheckoutPrice || 2198);
  }

  updateCheckoutPayable(basePrice) {
    const chk = document.getElementById("chk-use-wallet");
    const totalEl = document.getElementById("chk-total-payable");
    const subLabelEl = document.getElementById("chk-payable-sublabel");
    const titleLabelEl = document.getElementById("chk-payable-title-label");
    const ctaBtn = document.getElementById("chk-confirm-cta-btn");
    const sumTotalEl = document.getElementById("sum-final-payable");
    const sumWalletUsed = document.getElementById("sum-wallet-used");
    const origEl = document.getElementById("chk-original-payable");
    const deductLabel = document.getElementById("chk-wallet-deduct-label");

    const isUsing = chk && chk.checked;
    const walletDeduction = isUsing ? 100 : 0;
    const couponDeduction = this.appliedCouponDiscount || 0;
    const netTripFare = Math.max(0, basePrice - walletDeduction - couponDeduction);

    const payRadios = document.getElementsByName("pay-method");
    let method = "Direct UPI / QR Advance (₹299)";
    for (const r of payRadios) {
      if (r.checked) method = r.value;
    }

    const isCash = method.includes("Cash") || method.includes("Zero Advance") || method.includes("Driver");
    const isFull = !isCash && (method.includes("Full") || method.includes("100%"));
    const isUpi = !isCash && (method.includes("QR") || method.includes("PhonePe") || method.includes("Direct") || (method.includes("UPI") && !isCash));
    const isRzp = !isCash && !isUpi && (method.includes("Razorpay") || method.includes("Card") || method.includes("Advance (₹299)"));

    let payableNow = 0;
    let balanceDue = netTripFare;
    let titleLabel = "TOKEN ADVANCE NOW";
    let subLabel = "";
    let ctaText = "Confirm Booking (₹299 Advance) →";

    if (isCash) {
      payableNow = 0;
      balanceDue = netTripFare;
      titleLabel = "ADVANCE PAYABLE: ₹0";
      subLabel = `Total ₹${netTripFare.toLocaleString('en-IN')} payable to driver upon arrival`;
      ctaText = `Confirm Booking (₹0 Advance) →`;
    } else if (isFull) {
      payableNow = netTripFare;
      balanceDue = 0;
      titleLabel = "FULL ONLINE FARE";
      subLabel = `Zero balance payable to driver`;
      ctaText = `Pay ₹${payableNow.toLocaleString('en-IN')} & Confirm Cab →`;
    } else if (isUpi) {
      payableNow = Math.min(299, netTripFare);
      balanceDue = Math.max(0, netTripFare - payableNow);
      titleLabel = "SCAN & PAY ADVANCE";
      subLabel = `Balance due to driver: ₹${balanceDue.toLocaleString('en-IN')}`;
      ctaText = `Confirm Booking (₹${payableNow} Advance) →`;
    } else {
      payableNow = Math.min(299, netTripFare);
      balanceDue = Math.max(0, netTripFare - payableNow);
      titleLabel = "TOKEN ADVANCE NOW";
      subLabel = `Balance due to driver: ₹${balanceDue.toLocaleString('en-IN')}`;
      ctaText = this.dynamicPaymentConfig?.razorpayConfigured
        ? `Pay ₹${payableNow} with Razorpay →`
        : `Confirm Booking (₹${payableNow} Advance) →`;
    }

    if (deductLabel) {
      deductLabel.textContent = isUsing ? "-₹100" : "₹0";
    }
    if (origEl) {
      origEl.style.display = (isUsing || couponDeduction > 0) ? "inline" : "none";
    }
    if (totalEl) {
      totalEl.textContent = `₹${payableNow.toLocaleString('en-IN')}`;
    }
    if (titleLabelEl) {
      titleLabelEl.textContent = titleLabel;
    }
    if (subLabelEl) {
      subLabelEl.textContent = subLabel;
    }
    if (ctaBtn && !this.isSubmittingBooking) {
      ctaBtn.textContent = ctaText;
    }
    if (sumTotalEl) {
      sumTotalEl.textContent = `₹${netTripFare.toLocaleString('en-IN')}`;
    }
    if (sumWalletUsed) {
      sumWalletUsed.textContent = isUsing ? "-₹100" : "₹0";
      sumWalletUsed.style.color = isUsing ? "#059669" : "#94a3b8";
    }

    const upiId = this.dynamicPaymentConfig?.upiId || '8002141816@ybl';
    const rawPayee = this.dynamicPaymentConfig?.payeeName || 'Himanshu Kumar Dubey';
    const payeeName = encodeURIComponent(rawPayee);
    const amt = payableNow || 299;
    const upiUri = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;

    const qrEl = document.getElementById("chk-qr-img");
    if (qrEl) {
      qrEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=6&data=${encodeURIComponent(upiUri)}`;
    }

    const phonepeLink = document.getElementById("chk-upi-phonepe-link");
    if (phonepeLink) {
      phonepeLink.href = `phonepe://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
    }
    const gpayLink = document.getElementById("chk-upi-gpay-link");
    if (gpayLink) {
      gpayLink.href = `gpay://upi/pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
    }
    const paytmLink = document.getElementById("chk-upi-paytm-link");
    if (paytmLink) {
      paytmLink.href = `paytmmp://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
    }
    const upiLink = document.getElementById("chk-upi-intent-link");
    if (upiLink) {
      upiLink.href = upiUri;
    }
  }

  async syncPaymentConfig() {
    try {
      const res = await ApiClient.getPaymentConfig();
      if (res && res.success) {
        this.dynamicPaymentConfig = res;
        const upiId = res.upiId || '8002141816@ybl';
        const rawPayee = res.payeeName || 'Himanshu Kumar Dubey';
        const payeeName = encodeURIComponent(rawPayee);
        const amt = document.getElementById("chk-total-payable")?.textContent?.replace(/\D/g, '') || '299';
        const upiUri = `upi://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;

        const qrEl = document.getElementById("chk-qr-img");
        if (qrEl) {
          qrEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=6&data=${encodeURIComponent(upiUri)}`;
        }

        const payeeEl = document.getElementById("chk-payee-name");
        if (payeeEl && res.payeeName) payeeEl.textContent = res.payeeName;

        const upiLabel = document.getElementById("chk-upi-id-label");
        if (upiLabel && res.upiId) upiLabel.textContent = res.upiId;

        const rzpPill = document.getElementById("rzp-status-pill");
        if (rzpPill) {
          rzpPill.textContent = res.razorpayConfigured ? 'GATEWAY ACTIVE' : 'CARDS & NETBANKING';
          rzpPill.style.background = res.razorpayConfigured ? '#059669' : '#64748b';
        }

        const phonepeLink = document.getElementById("chk-upi-phonepe-link");
        if (phonepeLink) {
          phonepeLink.href = `phonepe://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
        }
        const gpayLink = document.getElementById("chk-upi-gpay-link");
        if (gpayLink) {
          gpayLink.href = `gpay://upi/pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
        }
        const paytmLink = document.getElementById("chk-upi-paytm-link");
        if (paytmLink) {
          paytmLink.href = `paytmmp://pay?pa=${upiId}&pn=${payeeName}&am=${amt}&cu=INR&tn=OneWayTaxiBihar%20Advance`;
        }
        const upiLink = document.getElementById("chk-upi-intent-link");
        if (upiLink) {
          upiLink.href = upiUri;
        }

        // Live Dynamic Bank Settlement Data
        const bNameEl = document.getElementById("chk-bank-name");
        if (bNameEl && res.bankName) bNameEl.textContent = res.bankName;

        const accHolderEl = document.getElementById("chk-account-holder");
        if (accHolderEl && (res.accountHolderName || res.payeeName)) {
          accHolderEl.textContent = res.accountHolderName || res.payeeName;
        }

        const accNumEl = document.getElementById("chk-account-number");
        if (accNumEl) accNumEl.textContent = res.accountNumber || 'Pending Configuration';

        const ifscEl = document.getElementById("chk-ifsc-code");
        if (ifscEl) ifscEl.textContent = res.ifscCode || 'SBIN0000001';

        const branchEl = document.getElementById("chk-bank-branch");
        if (branchEl && res.branchName) branchEl.textContent = res.branchName;
      }
    } catch (e) {
      console.warn("Payment config sync note:", e);
    }
  }

  async handleApplyCoupon(basePrice) {
    const input = document.getElementById("chk-coupon-input");
    const msgEl = document.getElementById("chk-coupon-msg");
    const btn = document.getElementById("chk-coupon-apply-btn");
    if (!input || !msgEl) return;

    const code = input.value.trim().toUpperCase();
    if (!code) {
      msgEl.style.display = "block";
      msgEl.style.color = "#ef4444";
      msgEl.textContent = "Please enter a valid coupon promo code.";
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = "...";
    }

    try {
      const res = await ApiClient.applyCoupon({ code, fareAmount: basePrice });
      if (res && res.success) {
        this.appliedCouponCode = res.code;
        this.appliedCouponDiscount = res.discount;

        msgEl.style.display = "block";
        msgEl.style.color = "#10b981";
        msgEl.innerHTML = `✓ <strong>${res.code} applied!</strong> You saved ₹${res.discount.toLocaleString('en-IN')}.`;

        const row = document.getElementById("sum-coupon-row");
        const codeEl = document.getElementById("sum-coupon-code");
        const discEl = document.getElementById("sum-coupon-discount");
        if (row) row.style.display = "flex";
        if (codeEl) codeEl.textContent = res.code;
        if (discEl) discEl.textContent = `-₹${res.discount.toLocaleString('en-IN')}`;

        this.updateCheckoutPayable(basePrice);
        if (window.showToast) window.showToast(`Coupon ${res.code} applied: -₹${res.discount}`, "success");
      } else {
        this.appliedCouponCode = "";
        this.appliedCouponDiscount = 0;
        msgEl.style.display = "block";
        msgEl.style.color = "#ef4444";
        msgEl.textContent = res?.message || 'Invalid or expired coupon code';

        const row = document.getElementById("sum-coupon-row");
        if (row) row.style.display = "none";
        this.updateCheckoutPayable(basePrice);
      }
    } catch (err) {
      console.error("Coupon apply error:", err);
      msgEl.style.display = "block";
      msgEl.style.color = "#ef4444";
      msgEl.textContent = "Network error verifying coupon.";
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Apply";
      }
    }
  }

  /* ==========================================================================
     INTELLIGENT LOCATION RECOMMENDATIONS & AUTO-TYPE CONTROLLER
     ========================================================================== */
  async setupCheckoutLocationAutocomplete() {
    const pickupInput = document.getElementById("chk-pickup-addr");
    const dropInput = document.getElementById("chk-drop-addr");
    const pickupChipsContainer = document.getElementById("pickup-auto-chips");
    const dropChipsContainer = document.getElementById("drop-auto-chips");
    const pickupDropdown = document.getElementById("chk-pickup-dropdown");
    const dropDropdown = document.getElementById("chk-drop-dropdown");

    if (!pickupInput || !dropInput) return;

    const originCityId = this.originCity ? this.originCity.id : "patna";
    const destCityId = this.destCity ? this.destCity.id : "gaya";
    const originCityName = this.originCity ? this.originCity.name : "Pickup City";
    const destCityName = this.destCity ? this.destCity.name : "Drop Destination";

    // 1. Fetch recommendations from backend with offline fallback
    let pickupRecs = null;
    let dropRecs = null;
    try {
      [pickupRecs, dropRecs] = await Promise.all([
        ApiClient.getLocationRecommendations(originCityId, "pickup"),
        ApiClient.getLocationRecommendations(destCityId, "drop")
      ]);
    } catch (e) {
      console.warn("Location recommendations fetch failed, using fallback:", e);
    }

    // 2. Render Quick Auto-Type Chips for Pickup
    if (pickupChipsContainer) {
      const chips = pickupRecs && pickupRecs.quickChips && pickupRecs.quickChips.length > 0 
        ? pickupRecs.quickChips 
        : [
            { label: "Airport Terminal", fullAddress: `Jay Prakash Narayan Airport, Terminal 1, ${originCityName}` },
            { label: "Railway Station (Main Gate)", fullAddress: `${originCityName} Junction, Platform 1 Main Gate, Station Road` },
            { label: "Central Bus Stand / ISBT", fullAddress: `Central Bus Stand / ISBT, ${originCityName}` },
            { label: "Civil / AIIMS Hospital", fullAddress: `Main Civil Hospital / Emergency Gate, ${originCityName}` },
            { label: "Main City Chowk", fullAddress: `Main City Chowk / Central Road, ${originCityName}` }
          ];

      pickupChipsContainer.innerHTML = `
        <div class="auto-type-header">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="color: #0284c7; flex-shrink: 0;"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
          <span style="font-weight: 750; color: #475569; font-size: 11px; letter-spacing: 0.4px; text-transform: uppercase;">Popular ${originCityName} Pickup Hubs (Tap to Fill):</span>
        </div>
        <div class="auto-type-chips-list">
          ${chips.map(c => `
            <button type="button" class="auto-type-chip" data-addr="${encodeURIComponent(c.fullAddress)}" title="1-Tap to auto-fill: ${c.fullAddress}">
              ${c.label}
            </button>
          `).join("")}
        </div>
      `;

      pickupChipsContainer.querySelectorAll(".auto-type-chip").forEach(btn => {
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          const addr = decodeURIComponent(btn.getAttribute("data-addr"));
          pickupInput.value = addr;
          this.passengerDetails.pickupAddress = addr;
          if (pickupDropdown) pickupDropdown.style.display = "none";
          btn.classList.add("chip-selected");
          setTimeout(() => btn.classList.remove("chip-selected"), 600);
          window.showToast(`Selected pickup: ${addr.split(',')[0]}`, "success");
        });
      });
    }

    // 3. Render Quick Auto-Type Chips for Drop
    if (dropChipsContainer) {
      const chips = dropRecs && dropRecs.quickChips && dropRecs.quickChips.length > 0 
        ? dropRecs.quickChips 
        : [
            { label: "Main Landmark / Temple", fullAddress: `Main Temple Complex / Historic Center, ${destCityName}` },
            { label: "Railway Junction", fullAddress: `${destCityName} Junction Railway Station, Main Exit` },
            { label: "City Center / Hotel Area", fullAddress: `Hotel / Guest House Area, ${destCityName}` },
            { label: "Central Bus Terminal", fullAddress: `Main Bus Stand, ${destCityName}` },
            { label: "District Hospital", fullAddress: `District Sadar Hospital, ${destCityName}` }
          ];

      dropChipsContainer.innerHTML = `
        <div class="auto-type-header">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="color: #f43f5e; flex-shrink: 0;"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/></svg>
          <span style="font-weight: 750; color: #475569; font-size: 11px; letter-spacing: 0.4px; text-transform: uppercase;">Popular ${destCityName} Drop Destinations (Tap to Fill):</span>
        </div>
        <div class="auto-type-chips-list">
          ${chips.map(c => `
            <button type="button" class="auto-type-chip" data-addr="${encodeURIComponent(c.fullAddress)}" title="1-Tap to auto-fill: ${c.fullAddress}">
              ${c.label}
            </button>
          `).join("")}
        </div>
      `;

      dropChipsContainer.querySelectorAll(".auto-type-chip").forEach(btn => {
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          const addr = decodeURIComponent(btn.getAttribute("data-addr"));
          dropInput.value = addr;
          this.passengerDetails.dropAddress = addr;
          if (dropDropdown) dropDropdown.style.display = "none";
          btn.classList.add("chip-selected");
          setTimeout(() => btn.classList.remove("chip-selected"), 600);
          window.showToast(`Selected drop: ${addr.split(',')[0]}`, "success");
        });
      });
    }

    // 4. Setup Dynamic Recommendation Dropdown on Focus & Typing
    const setupFieldDropdown = (input, dropdown, cityId, cityName, type) => {
      if (!input || !dropdown) return;

      const highlight = (text, term) => {
        if (!term || term.length < 2) return text;
        const idx = text.toLowerCase().indexOf(term.toLowerCase());
        if (idx === -1) return text;
        return text.substring(0, idx) + `<span class="chk-search-highlight">${text.substring(idx, idx + term.length)}</span>` + text.substring(idx + term.length);
      };

      const renderList = (items, query = "") => {
        if (!items || items.length === 0) {
          dropdown.innerHTML = `
            <div class="chk-loc-empty">
              <span>No pre-saved landmark matching "<strong>${query}</strong>".</span>
              <div style="font-size: 11px; margin-top: 4px; color: var(--owc-primary); font-weight: 600;">
                You can freely type your exact building, street, or village address.
              </div>
            </div>
          `;
          dropdown.style.display = "block";
          return;
        }

        // Group by category
        const groups = {};
        items.forEach(it => {
          const cat = it.category || "Recommended Hubs";
          if (!groups[cat]) groups[cat] = [];
          groups[cat].push(it);
        });

        let html = "";
        for (const [catName, catItems] of Object.entries(groups)) {
          html += `
            <div class="chk-loc-group-header">
              <span>${catName.toUpperCase()}</span>
              <span>1-Tap Auto-Type</span>
            </div>
          `;
          catItems.forEach((it, idx) => {
            html += `
              <div class="chk-loc-item ${idx === 0 && query ? 'active-item' : ''}" data-addr="${encodeURIComponent(it.address)}">
                <div class="chk-loc-item-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
                <div class="chk-loc-item-text">
                  <div class="chk-loc-item-name">
                    ${highlight(it.name, query)}
                    ${it.hindiName ? `<span class="chk-loc-hindi">(${it.hindiName})</span>` : ''}
                  </div>
                  <div class="chk-loc-item-sub">${highlight(it.address, query)}</div>
                </div>
                <span class="chk-loc-tag">${it.category}</span>
              </div>
            `;
          });
        }

        dropdown.innerHTML = html;
        dropdown.style.display = "block";

        dropdown.querySelectorAll(".chk-loc-item").forEach(item => {
          item.addEventListener("click", () => {
            const addr = decodeURIComponent(item.getAttribute("data-addr"));
            input.value = addr;
            if (type === "pickup") {
              this.passengerDetails.pickupAddress = addr;
            } else {
              this.passengerDetails.dropAddress = addr;
            }
            dropdown.style.display = "none";
            window.showToast(`Selected: ${addr.split(',')[0]}`, "success");
          });
        });
      };

      input.addEventListener("focus", async () => {
        const query = input.value.trim();
        if (!query) {
          const recs = type === "pickup" ? pickupRecs : dropRecs;
          if (recs && recs.locations && recs.locations.length > 0) {
            renderList(recs.locations);
          } else {
            const results = await ApiClient.getLocationRecommendations(cityId, type);
            renderList(results?.locations || []);
          }
        } else {
          const results = await ApiClient.searchLocations(query, cityId);
          renderList(results, query);
        }
      });

      input.addEventListener("input", async (e) => {
        const query = e.target.value.trim();
        if (type === "pickup") this.passengerDetails.pickupAddress = query;
        else this.passengerDetails.dropAddress = query;

        const results = await ApiClient.searchLocations(query, cityId);
        renderList(results, query);
      });

      input.addEventListener("keydown", (e) => {
        const items = dropdown.querySelectorAll(".chk-loc-item");
        if (!items.length || dropdown.style.display === "none") return;

        let activeIdx = -1;
        items.forEach((it, idx) => {
          if (it.classList.contains("active-item")) activeIdx = idx;
        });

        if (e.key === "ArrowDown") {
          e.preventDefault();
          const nextIdx = (activeIdx + 1) % items.length;
          items.forEach(it => it.classList.remove("active-item"));
          items[nextIdx].classList.add("active-item");
          items[nextIdx].scrollIntoView({ block: "nearest" });
        } else if (e.key === "ArrowUp") {
          e.preventDefault();
          const prevIdx = (activeIdx - 1 + items.length) % items.length;
          items.forEach(it => it.classList.remove("active-item"));
          items[prevIdx].classList.add("active-item");
          items[prevIdx].scrollIntoView({ block: "nearest" });
        } else if (e.key === "Enter") {
          e.preventDefault();
          if (activeIdx >= 0 && items[activeIdx]) {
            items[activeIdx].click();
          } else if (items.length > 0) {
            items[0].click();
          }
        } else if (e.key === "Escape") {
          dropdown.style.display = "none";
        }
      });
    };

    setupFieldDropdown(pickupInput, pickupDropdown, originCityId, originCityName, "pickup");
    setupFieldDropdown(dropInput, dropDropdown, destCityId, destCityName, "drop");

    // Close dropdowns on outside clicks
    document.addEventListener("click", (e) => {
      if (!e.target.closest("#chk-pickup-addr") && !e.target.closest("#chk-pickup-dropdown")) {
        if (pickupDropdown) pickupDropdown.style.display = "none";
      }
      if (!e.target.closest("#chk-drop-addr") && !e.target.closest("#chk-drop-dropdown")) {
        if (dropDropdown) dropDropdown.style.display = "none";
      }
    });
  }

  async confirmBooking(price) {
    if (this.isSubmittingBooking) return;

    if (!this.originCity || !this.originCity.name) {
      window.showToast("Please select a valid Pickup City/District", "warning");
      return;
    }
    if (!this.destCity || !this.destCity.name) {
      window.showToast("Please select a valid Drop City/District", "warning");
      return;
    }

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
    if (this.pickupDate && this.pickupDate < yStr) {
      window.showToast("Please choose a valid travel date (today or later)", "warning");
      return;
    }

    const nameInput = document.getElementById("chk-name");
    const phoneInput = document.getElementById("chk-phone");
    const name = nameInput?.value.trim() || this.passengerDetails.name || window.currentUser?.name || "";
    const phone = (phoneInput?.value || this.passengerDetails.phone || window.currentUser?.phone || "").replace(/\D/g, "").slice(-10);
    const email = document.getElementById("chk-email")?.value.trim() || this.passengerDetails.email || "";
    const pickupAddr = document.getElementById("chk-pickup-addr")?.value.trim() || this.passengerDetails.pickupAddress || `${this.originCity.name} City Area`;
    const dropAddr = document.getElementById("chk-drop-addr")?.value.trim() || this.passengerDetails.dropAddress || `${this.destCity.name} City Area`;
    
    if (!name || name.length < 2 || name.length > 60) {
      window.showToast("Please enter passenger full name (2 to 60 characters)", "warning");
      nameInput?.focus();
      return;
    }

    if (!phone || phone.length !== 10 || !/^[6-9]\d{9}$/.test(phone)) {
      window.showToast("Please enter a valid 10-digit Indian mobile number starting with 6-9", "warning");
      phoneInput?.focus();
      return;
    }

    // STRICT OTP VERIFICATION (Firebase Phone Auth / SMS OTP)
    // Ensures zero fake bookings and authentic verified passenger numbers
    const isSessionVerified = sessionStorage.getItem(`otb_verified_${phone}`) === "true" ||
      (window.currentUser && window.currentUser.isPhoneVerified && window.currentUser.phone?.includes(phone));

    if (!isSessionVerified && window.firebaseOtpService) {
      window.firebaseOtpService.requestVerification(phone, name, (verifyResult) => {
        // Once verified by Firebase/SMS, proceed with booking automatically
        this.confirmBooking(price);
      });
      return;
    }

    const payRadios = document.getElementsByName("pay-method");
    let method = "Direct UPI / QR Advance (₹299)";
    for (const r of payRadios) {
      if (r.checked) method = r.value;
    }

    const chkWallet = document.getElementById("chk-use-wallet");
    const isUsingWallet = chkWallet && chkWallet.checked;
    const utrInput = document.getElementById("chk-upi-utr");
    let utrVal = utrInput?.value.trim() || "";

    const netTripFare = Math.max(0, price - (isUsingWallet ? 100 : 0) - (this.appliedCouponDiscount || 0));
    const isCash = method.includes("Cash") || method.includes("Zero Advance") || method.includes("Driver");
    const isFullPayment = !isCash && (method.includes("Full") || method.includes("100%"));
    const isUpiQr = !isCash && (method.includes("QR") || method.includes("PhonePe") || method.includes("Direct") || (method.includes("UPI") && !isCash));
    const isRzpAdvance = !isCash && !isUpiQr && (method.includes("Razorpay") || method.includes("Card") || method.includes("Advance (₹299)"));

    let amountToCharge = 0;
    if (isCash) {
      amountToCharge = 0;
    } else if (isFullPayment) {
      amountToCharge = netTripFare;
    } else if (isRzpAdvance || isUpiQr) {
      amountToCharge = Math.min(299, netTripFare);
    } else {
      amountToCharge = 0;
    }

    if (isUpiQr && !utrVal) {
      utrVal = `UPI_DIRECT_${Date.now()}`;
      if (utrInput) utrInput.value = utrVal;
    }

    const btnConfirm = document.getElementById("chk-confirm-cta-btn") || document.querySelector("#modal-checkout .check-fare-primary-btn");
    if (btnConfirm) {
      btnConfirm.disabled = true;
      btnConfirm.innerHTML = `
        <span style="display:inline-block; width:15px; height:15px; border:2px solid #fff; border-top-color:transparent; border-radius:50%; animation:spin 0.8s linear infinite; vertical-align:middle; margin-right:8px;"></span>
        Processing Booking &amp; Confirmation...
      `;
    }
    this.isSubmittingBooking = true;

    try {
      const isRental = (this.tripType === "rental" || this.tripType === "local");
      const payload = {
        tripType: isRental ? "rental" : (this.tripType || "oneway"),
        rentalMode: isRental ? (this.rentalMode || "without_driver") : null,
        withDriver: isRental ? (this.rentalMode === "with_driver" || this.withDriver) : true,
        originCity: this.originCity.name,
        destCity: isRental ? `${this.originCity.name} (Rental Tour)` : (this.destCity?.name || "Local Destination"),
        pickupDate: this.pickupDate || yStr,
        pickupTime: this.pickupTime || "10:00 AM",
        cabTier: this.selectedCabId || "sedan",
        passengerName: name,
        passengerPhone: `+91 ${phone}`,
        passengerEmail: email,
        pickupAddress: pickupAddr,
        dropAddress: dropAddr,
        paymentMethod: method,
        useWallet: isUsingWallet,
        couponCode: this.appliedCouponCode || "",
        couponDiscount: this.appliedCouponDiscount || 0,
        totalFare: price,
        phoneVerified: true,
        verifiedMethod: "Fast2SMS Telecom OTP (Verified)",
        verifiedAt: new Date().toISOString(),
        advancePaid: amountToCharge,
        balanceDue: Math.max(0, netTripFare - amountToCharge),
        upiUtr: utrVal
      };

      // Live Razorpay Checkout flow ONLY if online cards/gateway selected AND configured with live keys
      const isRzpLive = Boolean(this.dynamicPaymentConfig?.razorpayConfigured);
      if ((isRzpAdvance || isFullPayment)) {
        if (!isRzpLive) {
          window.showToast?.("Razorpay gateway keys are in setup mode. Please select Direct PhonePe/GPay QR (0% Fee) or Cash to Driver.", "warning");
          const upiRadio = document.querySelector('input[name="pay-method"][value*="Direct UPI"]');
          if (upiRadio) {
            upiRadio.checked = true;
            this.handlePaymentMethodChange(upiRadio.value);
          }
          if (btnConfirm) {
            btnConfirm.disabled = false;
            this.updateCheckoutPayable(price);
          }
          this.isSubmittingBooking = false;
          return;
        }

        if (typeof window.Razorpay !== 'undefined') {
          try {
            const tempBId = `OTB-2026-${Math.floor(1000 + Math.random() * 9000)}`;
          const orderRes = await ApiClient.createPaymentOrder({
            amount: amountToCharge,
            bookingId: tempBId,
            passengerName: name,
            passengerPhone: phone,
            notes: { origin: this.originCity.name, dest: this.destCity.name, mode: method }
          });

          if (orderRes && orderRes.orderId && orderRes.keyId && !orderRes.keyId.includes('placeholder')) {
            const self = this;
            const rzp = new window.Razorpay({
              key: orderRes.keyId,
              amount: orderRes.amount || (amountToCharge * 100),
              currency: "INR",
              name: "OneWayTaxiBihar",
              description: isFullPayment ? `Full Cab Fare: ${this.originCity.name} to ${this.destCity.name}` : `Cab Token Advance: ${this.originCity.name} to ${this.destCity.name}`,
              image: "https://onewaytaxibihar.com/favicon.svg",
              order_id: orderRes.orderId,
              prefill: { name: name, contact: phone, email: email },
              theme: { color: "#0070f3" },
              modal: {
                ondismiss: function () {
                  if (btnConfirm) {
                    btnConfirm.disabled = false;
                    self.updateCheckoutPayable(price);
                  }
                  self.isSubmittingBooking = false;
                }
              },
              handler: async function (paymentResp) {
                payload.paymentMethod = isFullPayment ? "100% Full Pre-payment Online (Paid)" : "Razorpay Online Advance (₹299 Paid)";
                payload.paymentTxnId = paymentResp.razorpay_payment_id || `pay_rzp_${Date.now()}`;
                payload.advancePaid = amountToCharge;
                payload.balanceDue = Math.max(0, netTripFare - amountToCharge);
                
                const finalRes = await ApiClient.createBooking(payload);
                if (finalRes && finalRes.booking) {
                  try {
                    await ApiClient.verifyPayment({
                      orderId: paymentResp.razorpay_order_id || orderRes.orderId,
                      paymentId: paymentResp.razorpay_payment_id || payload.paymentTxnId,
                      signature: paymentResp.razorpay_signature || "sig_verified",
                      bookingId: finalRes.booking.bookingId,
                      amount: amountToCharge
                    });
                  } catch (vErr) {
                    console.warn('[Payment Verify Sync Note]:', vErr.message);
                  }
                  window.closeAllModals(false);
                  self.renderBookingConfirmation(finalRes.booking);
                }
              }
            });

            rzp.on('payment.failed', function (resp) {
              console.warn('Razorpay payment failed:', resp.error);
              window.showToast?.('Payment cancelled or declined. You can retry or choose Direct PhonePe QR / Cash to Driver.', 'info');
              if (btnConfirm) {
                btnConfirm.disabled = false;
                self.updateCheckoutPayable(price);
              }
              self.isSubmittingBooking = false;
            });

            rzp.open();
            return;
          }
        } catch (rzpErr) {
          console.warn('[Razorpay Flow Note]:', rzpErr.message);
        }
      }
    }

      const res = await ApiClient.createBooking(payload);

      if (res && res.success && res.booking) {
        const b = res.booking;
        if (isUsingWallet && window.currentUser) {
          window.currentUser.walletBalance = Math.max(0, (window.currentUser.walletBalance || 100) - (b.walletUsed || 100));
          if (window.renderNavAuth) window.renderNavAuth();
        }

        const phoneInputHero = document.getElementById("input-fare-phone");
        if (phoneInputHero) phoneInputHero.value = "";
        localStorage.removeItem("oneway_fare_phone");

        // Format detailed WhatsApp dispatch and customer ticket text
        const couponDetail = (b.couponDiscount > 0) ? `Coupon Applied: ${b.couponCode} (-₹${b.couponDiscount.toLocaleString('en-IN')})\n` : "";
        const waMsg = 
          `*NEW BOOKING CONFIRMATION - OneWayTaxiBihar*\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Booking ID: ${b.bookingId}\n` +
          `Trip OTP: ${b.tripOtp || 'Shared prior to trip'}\n` +
          `Passenger: ${b.passengerName}\n` +
          `Mobile: ${b.passengerPhone}\n` +
          `Route: ${b.originCity} ➔ ${b.destCity} (${b.distanceKm} KM)\n` +
          `Pickup Time: ${b.pickupDate} at ${b.pickupTime}\n` +
          `Pickup Address: ${b.pickupAddress}\n` +
          `Drop Address: ${b.dropAddress}\n` +
          `Cab Tier: ${b.fleetClass} (${b.fleetModel || 'Verified AC Cab'})\n` +
          couponDetail +
          `Total Fare: ₹${(b.totalFare || 0).toLocaleString('en-IN')} (Advance: ₹${b.advancePaid || 0}, Balance Due: ₹${b.balanceDue || 0})\n` +
          `Payment Method: ${b.paymentMethod}\n` +
          `Status: REQUESTED / CONFIRMED\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Our central dispatch agent will call you within 5 minutes.`;

        const rawWaNum = window.currentPlatformSettings?.cleanWhatsapp || this.dynamicPaymentConfig?.cleanWhatsapp || "917281851011";
        const cleanWaNum = rawWaNum.length === 10 ? `91${rawWaNum}` : rawWaNum;
        const waDispatchUrl = `https://wa.me/${cleanWaNum}?text=${encodeURIComponent(waMsg)}`;
        b.whatsappDispatchUrl = waDispatchUrl;
        b.whatsappMessage = waMsg;

        window.closeAllModals(false);
        this.renderBookingConfirmation(b);
        try {
          if (window.customerNotificationManager) {
            window.customerNotificationManager.onBookingSubmitted(b);
          }
        } catch(e) {}
      } else {
        window.showToast(res?.message || "Failed to submit booking request. Please check connection.", "warning");
        if (btnConfirm) {
          btnConfirm.disabled = false;
          this.updateCheckoutPayable(price);
        }
      }
    } catch (err) {
      console.error("Booking submission error:", err);
      window.showToast("Network error while submitting booking. Please try again.", "warning");
      if (btnConfirm) {
        btnConfirm.disabled = false;
        this.updateCheckoutPayable(price);
      }
    } finally {
      this.isSubmittingBooking = false;
    }
  }

  renderBookingConfirmation(booking) {
    const confModal = document.getElementById("modal-confirmation");
    const confBody = document.getElementById("modal-confirmation-body");

    if (!confModal || !confBody) return;

    const advancePaid = Number(booking.advancePaid) || 0;
    const totalFare = Number(booking.totalFare) || 0;
    const balanceDue = (booking.balanceDue !== undefined) ? Number(booking.balanceDue) : Math.max(0, totalFare - advancePaid);
    const isPaidOnline = Boolean(booking.paymentStatus && (booking.paymentStatus.includes('PAID') || booking.paymentStatus.includes('Online')));

    confBody.innerHTML = `
      <div class="booking-confirmation-voucher" style="text-align: center; padding: 4px 0; font-family: 'Inter', system-ui, -apple-system, sans-serif; width: 100%; box-sizing: border-box; min-width: 0; overflow-x: hidden;">
        
        <!-- Verification Header Badge -->
        <div style="width: 64px; height: 64px; border-radius: 50%; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px auto; box-shadow: 0 6px 18px rgba(16, 185, 129, 0.35);">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        
        <h2 style="font-size: 21px; font-weight: 900; color: var(--owc-text); margin: 0 0 4px 0; letter-spacing: -0.4px; line-height: 1.25;">Ride Confirmed &amp; Dispatched!</h2>
        <p style="font-size: 13px; color: var(--owc-text-muted); margin: 0 0 12px 0;">Your cab reservation has been secured. Our central dispatch is preparing your ride.</p>
        
        <!-- Booking Ref & Security OTP Pill -->
        <div style="display: inline-flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 8px; background: #f0fdf4; border: 1.5px solid #86efac; padding: 6px 14px; border-radius: 24px; font-size: 12px; font-weight: 800; margin-bottom: 14px;">
          <span style="color: #166534;">BOOKING ID: <strong style="font-family: monospace; font-size: 13px;">${booking.bookingId}</strong></span>
          ${booking.tripOtp ? `<span style="background: #0284c7; color: #fff; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 800;">TRIP START OTP: ${booking.tripOtp}</span>` : ''}
        </div>

        <!-- Live 3-Stage Dispatch Timeline -->
        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; text-align: left;">
          <div style="font-size: 11px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;">Live Dispatch Tracker</div>
          <div style="display: flex; align-items: center; justify-content: space-between; position: relative;">
            <div style="display: flex; flex-direction: column; align-items: center; gap: 4px; z-index: 1;">
              <span style="width: 22px; height: 22px; border-radius: 50%; background: #10b981; color: white; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800;">✓</span>
              <span style="font-size: 10px; font-weight: 800; color: #0f172a;">Requested</span>
            </div>
            <div style="flex: 1; height: 2px; background: #10b981; margin: 0 4px -14px 4px;"></div>
            <div style="display: flex; flex-direction: column; align-items: center; gap: 4px; z-index: 1;">
              <span style="width: 22px; height: 22px; border-radius: 50%; background: #0284c7; color: white; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800; animation: pulse 1.5s infinite;">2</span>
              <span style="font-size: 10px; font-weight: 800; color: #0284c7;">5-Min Call</span>
            </div>
            <div style="flex: 1; height: 2px; background: #cbd5e1; margin: 0 4px -14px 4px;"></div>
            <div style="display: flex; flex-direction: column; align-items: center; gap: 4px; z-index: 1;">
              <span style="width: 22px; height: 22px; border-radius: 50%; background: #cbd5e1; color: #475569; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800;">3</span>
              <span style="font-size: 10px; font-weight: 700; color: #94a3b8;">Driver OTP</span>
            </div>
          </div>
        </div>

        <!-- Official Central Dispatch 5-Minute Call Guarantee -->
        <div style="background: rgba(16, 185, 129, 0.06); border: 1.5px solid #059669; border-radius: var(--radius-lg); padding: 12px 14px; text-align: left; margin-bottom: 14px; width: 100%; box-sizing: border-box; min-width: 0;">
          <div style="display: flex; align-items: flex-start; gap: 10px; width: 100%; box-sizing: border-box; min-width: 0;">
            <div style="width: 36px; height: 36px; border-radius: 8px; background: #059669; color: white; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            </div>
            <div style="flex: 1; min-width: 0; word-break: break-word; overflow-wrap: anywhere;">
              <div style="font-size: 13.5px; font-weight: 800; color: #065f46; margin-bottom: 2px;">Central Dispatch Call Within 5 Minutes</div>
              <p style="font-size: 12px; color: #047857; margin: 0; line-height: 1.45;">
                Our Patna Operations room will call you at <strong>${booking.passengerPhone}</strong> within 5 minutes to confirm departure details and chauffeur assignment.
              </p>
            </div>
          </div>
        </div>

        <!-- Verified Trip Itinerary Card -->
        <div style="background: var(--owc-slate-50); border: 1px solid var(--owc-border); border-radius: var(--radius-lg); padding: 14px 16px; text-align: left; margin-bottom: 16px; font-size: 12.5px; line-height: 1.6; color: var(--owc-text); width: 100%; box-sizing: border-box; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 4px; border-bottom: 1px dashed var(--owc-border); padding-bottom: 6px; margin-bottom: 6px;">
            <span style="color: var(--owc-text-muted); font-size: 12px;">Lead Passenger:</span>
            <strong style="word-break: break-word; text-align: right;">${booking.passengerName} (${booking.passengerPhone})</strong>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 4px; border-bottom: 1px dashed var(--owc-border); padding-bottom: 6px; margin-bottom: 6px;">
            <span style="color: var(--owc-text-muted); font-size: 12px;">Route:</span>
            <strong style="word-break: break-word; text-align: right;">${booking.originCity} ➔ ${booking.destCity} (${booking.distanceKm} KM)</strong>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 4px; border-bottom: 1px dashed var(--owc-border); padding-bottom: 6px; margin-bottom: 6px;">
            <span style="color: var(--owc-text-muted); font-size: 12px;">Pickup Schedule:</span>
            <strong style="word-break: break-word; text-align: right;">${booking.pickupDate} at ${booking.pickupTime}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 4px; border-bottom: 1px dashed var(--owc-border); padding-bottom: 6px; margin-bottom: 6px;">
            <span style="color: var(--owc-text-muted); font-size: 12px;">Vehicle Tier:</span>
            <strong style="word-break: break-word; text-align: right;">${booking.fleetClass} (${booking.fleetModel || 'AC Cab'})</strong>
          </div>
          
          <!-- Financial Breakdown -->
          <div style="margin-top: 8px; padding-top: 8px; border-top: 1.5px solid var(--owc-border);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
              <span style="color: var(--owc-text-muted); font-size: 12px;">Total Trip Fare (All-Inclusive):</span>
              <strong style="color: var(--owc-text); font-size: 15px;">₹${totalFare.toLocaleString('en-IN')}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; color: #059669;">
              <span style="font-size: 12px;">Advance Paid:</span>
              <strong style="font-size: 14px;">₹${advancePaid.toLocaleString('en-IN')} (${booking.paymentMethod})</strong>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 4px; border-top: 1px dashed var(--owc-border);">
              <span style="font-weight: 700; color: var(--owc-text); font-size: 13px;">Remaining Balance Due to Driver:</span>
              <strong style="color: var(--owc-primary); font-size: 17px; font-weight: 900;">₹${balanceDue.toLocaleString('en-IN')}</strong>
            </div>
          </div>
          <div style="font-size: 11px; color: var(--owc-text-muted); text-align: right; margin-top: 4px;">
            Zero hidden charges • Toll, Fastag &amp; Driver Allowance 100% included
          </div>
        </div>

        <!-- Executive Action Buttons -->
        <div style="display: flex; flex-direction: column; gap: 8px; width: 100%; box-sizing: border-box;">
          ${booking.whatsappDispatchUrl ? `
            <a href="${booking.whatsappDispatchUrl}" target="_blank" rel="noopener noreferrer" style="text-decoration: none; width: 100%; box-sizing: border-box; background: #25D366; display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 14px; font-weight: 800; font-size: 13.5px; color: white; border-radius: var(--radius-md); box-shadow: 0 3px 10px rgba(37, 211, 102, 0.25);">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
              Send Ticket to Dispatch WhatsApp
            </a>
          ` : ''}

          <div style="display: flex; gap: 8px;">
            <button type="button" onclick="window.print()" class="btn-nav-outline" style="flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 11px 14px; font-weight: 700; font-size: 13px; border-color: #cbd5e1; color: var(--owc-text); background: white; cursor: pointer; border-radius: var(--radius-md);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              Print / Save Voucher
            </button>
            <a href="tel:+918002141816" class="btn-select-cab" style="text-decoration: none; flex: 1; background: #0284c7; display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 11px 14px; font-weight: 800; font-size: 13px; color: white; border-radius: var(--radius-md); box-shadow: 0 3px 10px rgba(2, 132, 199, 0.25);">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              24x7 Helpline
            </a>
          </div>

          <button type="button" onclick="window.closeAllModals(false)" style="width: 100%; margin-top: 4px; padding: 9px; background: transparent; border: none; color: var(--owc-text-muted); font-size: 12.5px; font-weight: 700; cursor: pointer; text-decoration: underline;">
            Close &amp; Return to Home
          </button>
        </div>
      </div>
    `;

    confModal.classList.add("open");
    document.body.classList.add("modal-open");
    history.pushState({ modal: "modal-confirmation" }, "", "#modal-confirmation");
    window.showToast("Booking request sent! Our agent will call you in 5 minutes.", "success");
  }
}

if (typeof window !== "undefined") {
  window.BookingManager = BookingManager;
}
