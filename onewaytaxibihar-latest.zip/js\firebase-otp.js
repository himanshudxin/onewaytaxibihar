/**
 * OneWayTaxiBihar - Dedicated Indian Telecom OTP & Verification Service
 * 
 * Powered by Fast2SMS Indian SMS Gateway (~₹0.20/SMS) + 24x7 WhatsApp Fallback (₹0)
 * Completely eliminates the expensive ~$0.057 (~₹5.15/SMS) Google Firebase Identity Platform fees.
 * 
 * Features:
 * 1. Ultra-Low Cost (~₹0.20 per OTP via Fast2SMS Indian Telecom route)
 * 2. Instant Zero-Cost WhatsApp fallback link for DND / delayed network SIMs
 * 3. 6-Digit Auto-Focusing Digit UI with copy-paste & auto-advance support
 * 4. Backward compatible with all existing window.firebaseOtpService calls
 * 5. Integrated with Mongo Atlas backend and booking dispatch desk
 */

(function () {
  'use strict';

  class TelecomOtpService {
    constructor() {
      this.isInitialized = true;
      this.provider = "Fast2SMS Indian Telecom Gateway";
      this.activePhone = "";
      this.activeName = "";
      this.onSuccessCallback = null;
      this.countdownTimer = null;
      this.remainingSeconds = 30;
      this.isVerifying = false;
      this.generatedOtpCode = "";
      this.isDemoMode = false;

      this.setupGlobalHandlers();
    }

    /**
     * Start the OTP verification flow for a booking or login
     * @param {string} phone 10-digit mobile number
     * @param {string} name Passenger name
     * @param {Function} onSuccess Callback when OTP is verified
     */
    async requestVerification(phone, name = "Passenger", onSuccess = null) {
      const clean10 = (phone || "").replace(/\D/g, "").slice(-10);
      if (!clean10 || clean10.length !== 10 || !/^[6-9]\d{9}$/.test(clean10)) {
        window.showToast?.("Please enter a valid 10-digit Indian mobile number", "warning");
        return false;
      }

      this.activePhone = clean10;
      this.activeName = name || "Passenger";
      this.onSuccessCallback = onSuccess;

      // Always open Modal UI and send fresh 6-digit SMS OTP via Fast2SMS
      this.openOtpModal(clean10);
      await this.sendOtpCode(clean10);
      return true;
    }

    async sendOtpCode(phone) {
      const clean10 = phone.replace(/\D/g, "").slice(-10);
      const statusEl = document.getElementById("otp-modal-status-text");

      if (statusEl) {
        statusEl.textContent = `Dispatching 6-digit SMS OTP to +91 ${clean10}...`;
        statusEl.style.color = "var(--owc-primary, #0084e8)";
      }

      this.startCountdown(30);

      // Trigger authoritative backend API to dispatch code via telecom SMS & WhatsApp
      try {
        if (window.ApiClient && ApiClient.sendOtp) {
          const apiRes = await ApiClient.sendOtp(clean10, this.activeName);
          if (!apiRes || !apiRes.success) {
            const errMsg = apiRes?.message || "Failed to send OTP. Please try again.";
            if (statusEl) {
              statusEl.textContent = errMsg;
              statusEl.style.color = "#ef4444";
            }
            window.showToast?.(errMsg, "error");
            return;
          }
        }
        if (window.ApiClient && ApiClient.sendLead) {
          ApiClient.sendLead({
            phone: clean10,
            passengerName: this.activeName || "Website Passenger",
            source: "Customer Mobile OTP Request"
          }).catch(() => {});
        }
      } catch (e) {
        console.warn("[Telecom OTP] Backend API send note:", e);
      }

      if (statusEl) {
        statusEl.textContent = `6-digit SMS OTP dispatched to +91 ${clean10}. Please check your phone messages.`;
        statusEl.style.color = "#059669";
      }
      window.showToast?.(`OTP SMS sent to +91 ${clean10}!`, "success");
      this.focusFirstDigit();
    }

    openOtpModal(phone) {
      window.closeAllModals?.(false);

      let modal = document.getElementById("modal-otp-verification");
      if (!modal) {
        this.createOtpModalDom();
        modal = document.getElementById("modal-otp-verification");
      }

      const phoneDisplay = document.getElementById("otp-modal-phone-display");
      if (phoneDisplay) {
        phoneDisplay.textContent = `+91 ${phone.substring(0, 5)} ${phone.substring(5)}`;
      }

      // Clear all 6 digit inputs
      for (let i = 1; i <= 6; i++) {
        const input = document.getElementById(`otp-box-${i}`);
        if (input) input.value = "";
      }

      if (modal) {
        modal.classList.add("open");
        document.body.classList.add("modal-open");
        history.pushState({ modal: "modal-otp-verification" }, "", "#otp-verify");
      }
    }

    closeOtpModal() {
      const modal = document.getElementById("modal-otp-verification");
      if (modal) {
        modal.classList.remove("open");
        document.body.classList.remove("modal-open");
      }
      if (this.countdownTimer) {
        clearInterval(this.countdownTimer);
      }
      this.isVerifying = false;
    }

    focusFirstDigit() {
      setTimeout(() => {
        const first = document.getElementById("otp-box-1");
        if (first) {
          first.focus();
          first.select();
        }
      }, 150);
    }

    autoFillCode(code) {
      const digits = (code || "").toString().replace(/\D/g, "").split("");
      for (let i = 1; i <= 6; i++) {
        const input = document.getElementById(`otp-box-${i}`);
        if (input) {
          input.value = digits[i - 1] || "";
        }
      }
      const lastInput = document.getElementById("otp-box-6");
      if (lastInput) lastInput.focus();

      // Trigger automatic verification after brief feedback
      setTimeout(() => {
        this.verifyEnteredCode();
      }, 300);
    }

    getEnteredCode() {
      let code = "";
      for (let i = 1; i <= 6; i++) {
        const input = document.getElementById(`otp-box-${i}`);
        if (input && input.value) {
          code += input.value.trim();
        }
      }
      return code;
    }

    async verifyEnteredCode() {
      if (this.isVerifying) return;

      const enteredCode = this.getEnteredCode();
      const statusEl = document.getElementById("otp-modal-status-text");
      const btnVerify = document.getElementById("btn-otp-submit-verify");

      if (!enteredCode || enteredCode.length !== 6) {
        window.showToast?.("Please enter the complete 6-digit OTP code", "warning");
        if (statusEl) {
          statusEl.textContent = "Please enter all 6 digits of your OTP";
          statusEl.style.color = "#ef4444";
        }
        return;
      }

      this.isVerifying = true;
      if (btnVerify) {
        btnVerify.disabled = true;
        btnVerify.innerHTML = `
          <span style="display:inline-block; width:15px; height:15px; border:2px solid #fff; border-top-color:transparent; border-radius:50%; animation:spin 0.8s linear infinite; vertical-align:middle; margin-right:8px;"></span>
          Verifying OTP...
        `;
      }

      try {
        let isVerified = false;
        let serverErrorMsg = "Invalid OTP code. Please enter the 6 digits sent to your phone.";

        try {
          if (window.ApiClient && ApiClient.verifyOtp) {
            const verifyRes = await ApiClient.verifyOtp(this.activePhone, enteredCode, this.activeName);
            if (verifyRes && verifyRes.success) {
              isVerified = true;
              if (verifyRes.user) {
                window.currentUser = verifyRes.user;
                localStorage.setItem("otb_current_user", JSON.stringify(verifyRes.user));
              }
            } else if (verifyRes && verifyRes.message) {
              serverErrorMsg = verifyRes.message;
            }
          }
        } catch (e) {
          console.warn("[Telecom OTP] Backend verify error:", e);
        }

        if (isVerified) {
          sessionStorage.setItem(`otb_verified_${this.activePhone}`, "true");
          localStorage.setItem("oneway_fare_phone", this.activePhone);

          if (!window.currentUser) {
            window.currentUser = {
              name: this.activeName || "Passenger",
              phone: `+91 ${this.activePhone}`,
              walletBalance: 100,
              isPhoneVerified: true
            };
          } else {
            window.currentUser.isPhoneVerified = true;
            window.currentUser.phone = `+91 ${this.activePhone}`;
          }
          localStorage.setItem("otb_current_user", JSON.stringify(window.currentUser));

          // Auto-sync verified customer login lead to Admin Portal
          if (window.ApiClient && ApiClient.sendLead) {
            ApiClient.sendLead({
              phone: this.activePhone,
              passengerName: this.activeName || "Valued Passenger",
              source: "Customer Mobile Verified Login"
            }).catch(() => {});
          }

          if (statusEl) {
            statusEl.textContent = "Mobile Number Verified Successfully!";
            statusEl.style.color = "#059669";
          }

          window.showToast?.("Mobile number verified successfully!", "success");

          setTimeout(() => {
            this.closeOtpModal();
            if (typeof this.onSuccessCallback === "function") {
              this.onSuccessCallback({
                phone: this.activePhone,
                verified: true,
                verifiedAt: new Date().toISOString(),
                method: "Authoritative Telecom OTP (Verified)"
              });
            }
          }, 450);

        } else {
          if (statusEl) {
            statusEl.textContent = serverErrorMsg;
            statusEl.style.color = "#ef4444";
          }
          window.showToast?.(serverErrorMsg, "error");

          const grid = document.querySelector(".otp-digit-grid");
          if (grid) {
            grid.classList.add("shake-error");
            setTimeout(() => grid.classList.remove("shake-error"), 600);
          }
        }
      } catch (err) {
        console.error("[Telecom OTP] Verification error:", err);
        window.showToast?.("Verification failed. Please try resending OTP.", "error");
      } finally {
        this.isVerifying = false;
        if (btnVerify) {
          btnVerify.disabled = false;
          btnVerify.innerHTML = `Verify &amp; Confirm Booking →`;
        }
      }
    }

    startCountdown(seconds = 30) {
      if (this.countdownTimer) clearInterval(this.countdownTimer);
      this.remainingSeconds = seconds;

      const timerEl = document.getElementById("otp-resend-timer-label");
      const btnResend = document.getElementById("btn-otp-resend");

      const updateUI = () => {
        if (this.remainingSeconds > 0) {
          if (timerEl) timerEl.textContent = `Resend code in ${this.remainingSeconds}s`;
          if (btnResend) {
            btnResend.disabled = true;
            btnResend.style.opacity = "0.5";
            btnResend.style.cursor = "not-allowed";
          }
        } else {
          clearInterval(this.countdownTimer);
          if (timerEl) timerEl.textContent = "Didn't receive code?";
          if (btnResend) {
            btnResend.disabled = false;
            btnResend.style.opacity = "1";
            btnResend.style.cursor = "pointer";
            btnResend.textContent = "Resend OTP";
          }
        }
      };

      updateUI();
      this.countdownTimer = setInterval(() => {
        this.remainingSeconds--;
        updateUI();
      }, 1000);
    }

    async resendOtp() {
      if (this.remainingSeconds > 0) return;
      if (!this.activePhone) {
        this.activePhone = window.bookingManager?.userPhone || localStorage.getItem("oneway_fare_phone") || "";
      }
      if (this.activePhone) {
        await this.sendOtpCode(this.activePhone);
      }
    }

    sendOtpViaWhatsApp() {
      const clean10 = this.activePhone;
      if (!clean10) return;
      const code = sessionStorage.getItem(`otb_temp_otp_${clean10}`) || sessionStorage.getItem(`otb_verify_${clean10}`) || this.generatedOtpCode;
      const text = `Hi OneWayTaxiBihar, please verify my mobile number +91 ${clean10}. My verification code is: ${code}`;
      const url = `https://wa.me/917281851011?text=${encodeURIComponent(text)}`;
      window.open(url, "_blank");
      window.showToast?.("Opening 24x7 WhatsApp Dispatch Desk for instant verification code...", "info");
    }

    editPhoneNumber() {
      this.closeOtpModal();
      const phoneInput = document.getElementById("input-fare-phone") || document.getElementById("chk-phone");
      if (phoneInput) {
        phoneInput.focus();
        phoneInput.select();
      }
    }

    createOtpModalDom() {
      const existing = document.getElementById("modal-otp-verification");
      if (existing) return;

      const modalHtml = `
        <div class="modal-overlay" id="modal-otp-verification" role="dialog" aria-modal="true" aria-labelledby="otp-modal-title">
          <div class="modal-dialog-box small" style="max-width: 440px; padding: 0; overflow: hidden; border-radius: 16px; border: 1px solid var(--owc-border, #e2e8f0); box-shadow: 0 20px 40px rgba(0,0,0,0.25);">
            
            <!-- Modal Header with Security & Telecom Branding -->
            <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 22px 20px 18px; color: #ffffff; text-align: center; position: relative;">
              <button type="button" class="modal-close-btn" onclick="window.otpService.closeOtpModal()" aria-label="Close" style="position: absolute; right: 14px; top: 14px; color: #94a3b8; background: rgba(255,255,255,0.08); border: none; width: 30px; height: 30px; border-radius: 50%; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center;">✕</button>
              
              <div style="width: 52px; height: 52px; margin: 0 auto 10px; border-radius: 50%; background: rgba(0, 154, 244, 0.15); border: 2px solid #38bdf8; display: flex; align-items: center; justify-content: center; color: #38bdf8;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>

              <h3 id="otp-modal-title" style="font-size: 19px; font-weight: 800; margin: 0 0 4px 0; color: #ffffff; letter-spacing: -0.2px;">Verify Mobile Number</h3>
              <p style="font-size: 12.5px; color: #94a3b8; margin: 0; line-height: 1.4;">
                Enter 6-digit OTP code to confirm your ride &amp; lock chauffeur dispatch
              </p>
            </div>

            <!-- Modal Body -->
            <div class="modal-body" style="padding: 20px 22px 24px; text-align: center; background: var(--owc-card-bg, #ffffff);">
              
              <!-- Sent To Phone Number Bar -->
              <div style="background: rgba(0, 154, 244, 0.06); border: 1px solid rgba(0, 154, 244, 0.2); border-radius: 10px; padding: 9px 12px; margin-bottom: 18px; display: flex; align-items: center; justify-content: space-between;">
                <div style="text-align: left;">
                  <span style="font-size: 10.5px; color: var(--owc-text-muted, #64748b); text-transform: uppercase; font-weight: 700; display: block;">SMS OTP SENT TO:</span>
                  <strong id="otp-modal-phone-display" style="font-size: 14px; color: var(--owc-text, #0f172a); font-weight: 800;">+91 98765 43210</strong>
                </div>
                <button type="button" onclick="window.otpService.editPhoneNumber()" style="border: none; background: #e0f2fe; color: #0284c7; padding: 4px 10px; border-radius: 6px; font-size: 11.5px; font-weight: 700; cursor: pointer;">
                  Edit
                </button>
              </div>

              <!-- 6 Individual Digit Inputs -->
              <div class="otp-digit-grid" style="display: flex; justify-content: center; gap: 8px; margin-bottom: 16px;">
                <input type="tel" maxlength="1" id="otp-box-1" class="otp-box-input" autocomplete="one-time-code" autofocus>
                <input type="tel" maxlength="1" id="otp-box-2" class="otp-box-input">
                <input type="tel" maxlength="1" id="otp-box-3" class="otp-box-input">
                <input type="tel" maxlength="1" id="otp-box-4" class="otp-box-input">
                <input type="tel" maxlength="1" id="otp-box-5" class="otp-box-input">
                <input type="tel" maxlength="1" id="otp-box-6" class="otp-box-input">
              </div>

              <!-- Dynamic Status Message -->
              <div id="otp-modal-status-text" style="font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 16px; min-height: 18px;">
                Enter the 6-digit code received via SMS
              </div>

              <!-- Submit Button -->
              <button type="button" id="btn-otp-submit-verify" class="check-fare-primary-btn" style="width: 100%; min-height: 48px; font-size: 14.5px; font-weight: 800; margin-bottom: 14px;" onclick="window.otpService.verifyEnteredCode()">
                Verify &amp; Confirm Booking →
              </button>

              <!-- Resend Timer Row -->
              <div style="display: flex; align-items: center; justify-content: space-between; font-size: 12px; border-top: 1px solid var(--owc-border, #e2e8f0); padding-top: 14px; margin-top: 4px;">
                <span id="otp-resend-timer-label" style="color: var(--owc-text-muted, #64748b); font-weight: 600;">Resend code in 30s</span>
                <button type="button" id="btn-otp-resend" onclick="window.otpService.resendOtp()" style="border: none; background: transparent; color: var(--owc-primary, #0084e8); font-weight: 700; font-size: 12px; cursor: pointer; text-decoration: underline;" disabled>
                  Resend OTP
                </button>
              </div>

              <!-- Instant WhatsApp Verification Fallback -->
              <div style="margin-top: 14px; text-align: center;">
                <a href="javascript:void(0)" onclick="window.otpService.sendOtpViaWhatsApp()" style="display: flex; align-items: center; justify-content: center; gap: 6px; padding: 9px 12px; background: #ecfdf5; border: 1px solid #10b981; border-radius: 8px; color: #047857; text-decoration: none; font-size: 12.5px; font-weight: 700;">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2z"/></svg>
                  <span>Didn't receive SMS? Get OTP via WhatsApp (Free &amp; Instant)</span>
                </a>
              </div>

            </div>

          </div>
        </div>
      `;

      const container = document.createElement("div");
      container.innerHTML = modalHtml;
      document.body.appendChild(container.firstElementChild);

      this.setupDigitInputs();
    }

    setupDigitInputs() {
      for (let i = 1; i <= 6; i++) {
        const input = document.getElementById(`otp-box-${i}`);
        if (!input) continue;

        // Auto jump to next on input
        input.addEventListener("input", (e) => {
          const val = e.target.value.replace(/\D/g, "");
          e.target.value = val ? val[val.length - 1] : "";

          if (val && i < 6) {
            const next = document.getElementById(`otp-box-${i + 1}`);
            if (next) {
              next.focus();
              next.select();
            }
          }

          // Check if all 6 digits entered, auto submit!
          const fullCode = this.getEnteredCode();
          if (fullCode.length === 6) {
            setTimeout(() => this.verifyEnteredCode(), 150);
          }
        });

        // Handle Backspace navigation
        input.addEventListener("keydown", (e) => {
          if (e.key === "Backspace" && !input.value && i > 1) {
            const prev = document.getElementById(`otp-box-${i - 1}`);
            if (prev) {
              prev.focus();
              prev.value = "";
            }
          } else if (e.key === "Enter") {
            e.preventDefault();
            this.verifyEnteredCode();
          }
        });

        // Handle Paste (e.g. copying 6-digit SMS code from keyboard/clipboard)
        input.addEventListener("paste", (e) => {
          e.preventDefault();
          const pasteData = (e.clipboardData || window.clipboardData).getData("text");
          if (pasteData) {
            this.autoFillCode(pasteData);
          }
        });
      }
    }

    setupGlobalHandlers() {
      // Expose to window for inline calls
      window.requestOtpVerification = (phone, name, callback) => this.requestVerification(phone, name, callback);
      window.verifyEnteredOtp = () => this.verifyEnteredCode();
      window.resendOtp = () => this.resendOtp();
    }
  }

  // Inject CSS styles for OTP input boxes
  const style = document.createElement("style");
  style.textContent = `
    .otp-box-input {
      width: 48px;
      height: 52px;
      border: 1.5px solid var(--owc-border, #cbd5e1);
      border-radius: 10px;
      text-align: center;
      font-size: 22px;
      font-weight: 800;
      color: var(--owc-text, #0f172a);
      background: var(--owc-card-bg, #ffffff);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      outline: none;
      font-family: monospace;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .otp-box-input:focus {
      border-color: var(--owc-primary, #0084e8);
      box-shadow: 0 0 0 3px rgba(0, 132, 232, 0.18);
      transform: translateY(-2px);
    }
    .shake-error {
      animation: otpShake 0.4s cubic-bezier(.36,.07,.19,.97) both;
    }
    @keyframes otpShake {
      10%, 90% { transform: translate3d(-1px, 0, 0); }
      20%, 80% { transform: translate3d(2px, 0, 0); }
      30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
      40%, 60% { transform: translate3d(4px, 0, 0); }
    }
    @media (max-width: 480px) {
      .otp-box-input {
        width: 40px;
        height: 46px;
        font-size: 19px;
      }
    }
  `;
  document.head.appendChild(style);

  // Initialize service instance & provide backwards-compatible alias
  const instance = new TelecomOtpService();
  window.otpService = instance;
  window.firebaseOtpService = instance; // Backwards-compatible alias for existing booking.js calls

})();
